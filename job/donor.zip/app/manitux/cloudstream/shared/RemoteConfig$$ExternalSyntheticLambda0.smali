.class public final synthetic Lapp/manitux/cloudstream/shared/RemoteConfig$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x12
    versionHash = "7de78e4c4546435adeebf26ef4b0cc5c4f405847ffd476305b2b34259a231191"
.end annotation


# instance fields
.field public final synthetic f$0:Lapp/manitux/cloudstream/shared/RemoteConfig;


# direct methods
.method public synthetic constructor <init>(Lapp/manitux/cloudstream/shared/RemoteConfig;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$$ExternalSyntheticLambda0;->f$0:Lapp/manitux/cloudstream/shared/RemoteConfig;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$$ExternalSyntheticLambda0;->f$0:Lapp/manitux/cloudstream/shared/RemoteConfig;

    check-cast p1, Ljava/util/Map$Entry;

    invoke-static {v0, p1}, Lapp/manitux/cloudstream/shared/RemoteConfig;->$r8$lambda$HRJGdiRLBxFHi1J3SHnnFknjA7w(Lapp/manitux/cloudstream/shared/RemoteConfig;Ljava/util/Map$Entry;)Lkotlin/Pair;

    move-result-object p1

    return-object p1
.end method
