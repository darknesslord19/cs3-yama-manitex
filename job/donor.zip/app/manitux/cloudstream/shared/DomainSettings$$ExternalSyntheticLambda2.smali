.class public final synthetic Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x12
    versionHash = "7de78e4c4546435adeebf26ef4b0cc5c4f405847ffd476305b2b34259a231191"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/app/AlertDialog;

.field public final synthetic f$1:Landroid/widget/EditText;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Ljava/lang/String;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$5:Landroid/content/Context;

.field public final synthetic f$6:Ljava/lang/String;

.field public final synthetic f$7:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$0:Landroid/app/AlertDialog;

    iput-object p2, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$1:Landroid/widget/EditText;

    iput-object p3, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$2:Ljava/lang/String;

    iput-object p4, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$3:Ljava/lang/String;

    iput-object p5, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$4:Lkotlin/jvm/functions/Function1;

    iput-object p6, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$5:Landroid/content/Context;

    iput-object p7, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$6:Ljava/lang/String;

    iput-object p8, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$7:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .registers 11

    .line 0
    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$0:Landroid/app/AlertDialog;

    iget-object v1, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$1:Landroid/widget/EditText;

    iget-object v2, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$2:Ljava/lang/String;

    iget-object v3, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$3:Ljava/lang/String;

    iget-object v4, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$4:Lkotlin/jvm/functions/Function1;

    iget-object v5, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$5:Landroid/content/Context;

    iget-object v6, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$6:Ljava/lang/String;

    iget-object v7, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;->f$7:Ljava/lang/String;

    move-object v8, p1

    invoke-static/range {v0 .. v8}, Lapp/manitux/cloudstream/shared/DomainSettings;->$r8$lambda$RtYK8Pyk5JSqsI22KmaithNXBXs(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/DialogInterface;)V

    return-void
.end method
