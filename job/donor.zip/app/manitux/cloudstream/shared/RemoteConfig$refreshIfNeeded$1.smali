.class final Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;
.super Lkotlin/coroutines/jvm/internal/ContinuationImpl;
.source "RemoteConfig.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshIfNeeded(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "app.manitux.cloudstream.shared.RemoteConfig"
    f = "RemoteConfig.kt"
    i = {
        0x0,
        0x0,
        0x0,
        0x1,
        0x1,
        0x1,
        0x1,
        0x1
    }
    l = {
        0x6a,
        0x43
    }
    m = "refreshIfNeeded"
    n = {
        "$this$withLock_u24default$iv",
        "force",
        "$i$f$withLock",
        "$this$withLock_u24default$iv",
        "force",
        "$i$f$withLock",
        "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2",
        "now"
    }
    nl = {
        0x6b,
        0x44
    }
    s = {
        "L$0",
        "Z$0",
        "I$0",
        "L$0",
        "Z$0",
        "I$0",
        "I$1",
        "J$0"
    }
    v = 0x2
.end annotation


# instance fields
.field I$0:I

.field I$1:I

.field J$0:J

.field L$0:Ljava/lang/Object;

.field Z$0:Z

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lapp/manitux/cloudstream/shared/RemoteConfig;


# direct methods
.method constructor <init>(Lapp/manitux/cloudstream/shared/RemoteConfig;Lkotlin/coroutines/Continuation;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lapp/manitux/cloudstream/shared/RemoteConfig;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->this$0:Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/ContinuationImpl;-><init>(Lkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5
    .param p1  # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->result:Ljava/lang/Object;

    iget v0, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    const/high16 v1, -0x80000000

    or-int/2addr v0, v1

    iput v0, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    iget-object v0, p0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->this$0:Lapp/manitux/cloudstream/shared/RemoteConfig;

    const/4 v1, 0x0

    move-object v2, p0

    check-cast v2, Lkotlin/coroutines/Continuation;

    invoke-static {v0, v1, v2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->access$refreshIfNeeded(Lapp/manitux/cloudstream/shared/RemoteConfig;ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
