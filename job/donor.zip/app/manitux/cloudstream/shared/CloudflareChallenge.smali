.class public final Lapp/manitux/cloudstream/shared/CloudflareChallenge;
.super Ljava/lang/Object;
.source "CloudflareChallenge.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCloudflareChallenge.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CloudflareChallenge.kt\napp/manitux/cloudstream/shared/CloudflareChallenge\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,19:1\n1#2:20\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t¨\u0006\n"
    }
    d2 = {
        "Lapp/manitux/cloudstream/shared/CloudflareChallenge;",
        "",
        "<init>",
        "()V",
        "isChallenge",
        "",
        "code",
        "",
        "html",
        "",
        "FilmMakinesi_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nCloudflareChallenge.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CloudflareChallenge.kt\napp/manitux/cloudstream/shared/CloudflareChallenge\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,19:1\n1#2:20\n*E\n"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lapp/manitux/cloudstream/shared/CloudflareChallenge;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lapp/manitux/cloudstream/shared/CloudflareChallenge;

    invoke-direct {v0}, Lapp/manitux/cloudstream/shared/CloudflareChallenge;-><init>()V

    sput-object v0, Lapp/manitux/cloudstream/shared/CloudflareChallenge;->INSTANCE:Lapp/manitux/cloudstream/shared/CloudflareChallenge;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final isChallenge(ILjava/lang/String;)Z
    .registers 12
    .param p1, "code"  # I
    .param p2, "html"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 8
    move-object v0, p2

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trimStart(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 20
    .local v0, "it":Ljava/lang/String;
    const/4 v1, 0x0

    .line 8
    .local v1, "$i$a$-let-CloudflareChallenge$isChallenge$1":I
    const-string v2, "{"

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0, v2, v3, v4, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x1

    if-nez v2, :cond_23

    const-string v2, "["

    invoke-static {v0, v2, v3, v4, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    goto :goto_23

    :cond_21
    const/4 v0, 0x0

    goto :goto_24

    :cond_23
    :goto_23
    const/4 v0, 0x1

    .end local v0  # "it":Ljava/lang/String;
    .end local v1  # "$i$a$-let-CloudflareChallenge$isChallenge$1":I
    :goto_24
    if-eqz v0, :cond_27

    return v3

    .line 9
    :cond_27
    invoke-static {p2}, Lorg/jsoup/Jsoup;->parse(Ljava/lang/String;)Lorg/jsoup/nodes/Document;

    move-result-object v0

    .line 10
    .local v0, "doc":Lorg/jsoup/nodes/Document;
    invoke-virtual {v0}, Lorg/jsoup/nodes/Document;->title()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 11
    .local v1, "title":Ljava/lang/String;
    const-string v2, "Just a moment..."

    invoke-static {v1, v2, v6}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_99

    .line 12
    const-string v2, "Attention Required! | Cloudflare"

    invoke-static {v1, v2, v6}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_99

    .line 13
    const-string v2, "#challenge-form, #challenge-running, #cf-challenge-running"

    invoke-virtual {v0, v2}, Lorg/jsoup/nodes/Document;->selectFirst(Ljava/lang/String;)Lorg/jsoup/nodes/Element;

    move-result-object v2

    if-nez v2, :cond_99

    .line 14
    move-object v2, p2

    check-cast v2, Ljava/lang/CharSequence;

    const-string v7, "_cf_chl_opt"

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v2, v7, v3, v4, v5}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_98

    .line 15
    const/16 v2, 0x193

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/16 v5, 0x1ad

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/16 v7, 0x1f7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v8, 0x3

    new-array v8, v8, [Ljava/lang/Integer;

    aput-object v2, v8, v3

    aput-object v5, v8, v6

    aput-object v7, v8, v4

    invoke-static {v8}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_99

    .line 16
    invoke-virtual {v0}, Lorg/jsoup/nodes/Document;->text()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    const-string v4, "Enable JavaScript and cookies to continue"

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v2, v4, v6}, Lkotlin/text/StringsKt;->contains(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v2

    if-eqz v2, :cond_98

    goto :goto_99

    :cond_98
    goto :goto_9a

    :cond_99
    :goto_99
    const/4 v3, 0x1

    .line 11
    :goto_9a
    return v3
.end method
