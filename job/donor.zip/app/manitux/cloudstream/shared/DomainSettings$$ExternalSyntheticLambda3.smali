.class public final synthetic Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x12
    versionHash = "7de78e4c4546435adeebf26ef4b0cc5c4f405847ffd476305b2b34259a231191"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/lang/String;

.field public final synthetic f$3:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$4:Landroid/content/Context;

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:Landroid/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$0:Landroid/widget/EditText;

    iput-object p2, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$2:Ljava/lang/String;

    iput-object p4, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$3:Lkotlin/jvm/functions/Function1;

    iput-object p5, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$4:Landroid/content/Context;

    iput-object p6, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$5:Ljava/lang/String;

    iput-object p7, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$6:Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 10

    .line 0
    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$0:Landroid/widget/EditText;

    iget-object v1, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$2:Ljava/lang/String;

    iget-object v3, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$3:Lkotlin/jvm/functions/Function1;

    iget-object v4, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$4:Landroid/content/Context;

    iget-object v5, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$5:Ljava/lang/String;

    iget-object v6, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;->f$6:Landroid/app/AlertDialog;

    move-object v7, p1

    invoke-static/range {v0 .. v7}, Lapp/manitux/cloudstream/shared/DomainSettings;->$r8$lambda$tZoDllSsNadkvCFH6jvQS5jQJ8k(Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method
