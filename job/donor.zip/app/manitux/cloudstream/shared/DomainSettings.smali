.class public final Lapp/manitux/cloudstream/shared/DomainSettings;
.super Ljava/lang/Object;
.source "DomainSettings.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDomainSettings.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DomainSettings.kt\napp/manitux/cloudstream/shared/DomainSettings\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,183:1\n1#2:184\n1401#3,2:185\n1088#4,2:187\n*S KotlinDebug\n*F\n+ 1 DomainSettings.kt\napp/manitux/cloudstream/shared/DomainSettings\n*L\n70#1:185,2\n176#1:187,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000V\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010\"\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010J\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0012\u001a\u00020\u0005J\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00050\f2\u0006\u0010\u0012\u001a\u00020\u0005J\u0016\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005J:\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u001a\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u00052\u0012\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0\u001dJ\u001a\u0010\u001e\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u00052\b\u0010\u001f\u001a\u0004\u0018\u00010\u0005H\u0002J:\u0010 \u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u001a\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u00052\u0012\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0\u001dJ\u0010\u0010!\u001a\u00020\u000e2\u0006\u0010\"\u001a\u00020#H\u0002J\u0017\u0010$\u001a\u0004\u0018\u00010%2\u0006\u0010\u001f\u001a\u00020\u0005H\u0000¢\u0006\u0002\b&R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\n\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\f0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\'"
    }
    d2 = {
        "Lapp/manitux/cloudstream/shared/DomainSettings;",
        "",
        "<init>",
        "()V",
        "PREFS_NAME",
        "",
        "KEY_PREFIX",
        "TAG",
        "preferences",
        "Landroid/content/SharedPreferences;",
        "domainHistory",
        "",
        "",
        "initialize",
        "",
        "context",
        "Landroid/content/Context;",
        "getOverride",
        "key",
        "knownDomains",
        "rememberDomain",
        "domain",
        "installIfSupported",
        "",
        "plugin",
        "Lcom/lagradost/cloudstream3/plugins/Plugin;",
        "displayName",
        "fallback",
        "onChanged",
        "Lkotlin/Function1;",
        "save",
        "value",
        "showDomainDialog",
        "selectDomainExtension",
        "input",
        "Landroid/widget/EditText;",
        "domainExtensionRange",
        "Lkotlin/ranges/IntRange;",
        "domainExtensionRange$FilmMakinesi_debug",
        "FilmMakinesi_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nDomainSettings.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DomainSettings.kt\napp/manitux/cloudstream/shared/DomainSettings\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,183:1\n1#2:184\n1401#3,2:185\n1088#4,2:187\n*S KotlinDebug\n*F\n+ 1 DomainSettings.kt\napp/manitux/cloudstream/shared/DomainSettings\n*L\n70#1:185,2\n176#1:187,2\n*E\n"
    }
.end annotation


# static fields
.field public static final INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final KEY_PREFIX:Ljava/lang/String; = "domain_"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final PREFS_NAME:Ljava/lang/String; = "manitux_plugin_domains"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final TAG:Ljava/lang/String; = "Manitux_DomainSettings"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final domainHistory:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static volatile preferences:Landroid/content/SharedPreferences;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$RtYK8Pyk5JSqsI22KmaithNXBXs(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/DialogInterface;)V
    .registers 9

    invoke-static/range {p0 .. p8}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog$lambda$2(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/DialogInterface;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ZsHhRAWNbyjhyXYqSshE_Gj4Yhc(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lapp/manitux/cloudstream/shared/DomainSettings;->installIfSupported$lambda$2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jrk7IXfNC_qE2OgYJHnP0JYjO7A(Landroid/widget/EditText;Landroid/view/View;Z)V
    .registers 3

    invoke-static {p0, p1, p2}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog$lambda$0$0(Landroid/widget/EditText;Landroid/view/View;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$tZoDllSsNadkvCFH6jvQS5jQJ8k(Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V
    .registers 8

    invoke-static/range {p0 .. p7}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog$lambda$2$0(Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$x0UCYOXqTW2WwRCC0kRymA31i50(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V
    .registers 7

    invoke-static/range {p0 .. p6}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog$lambda$2$1(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-direct {v0}, Lapp/manitux/cloudstream/shared/DomainSettings;-><init>()V

    sput-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    .line 29
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v0, Ljava/util/Map;

    sput-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->domainHistory:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final installIfSupported$lambda$2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;)Lkotlin/Unit;
    .registers 11
    .param p0, "$key"  # Ljava/lang/String;
    .param p1, "$displayName"  # Ljava/lang/String;
    .param p2, "$fallback"  # Ljava/lang/String;
    .param p3, "$onChanged"  # Lkotlin/jvm/functions/Function1;
    .param p4, "context"  # Landroid/content/Context;

    .line 77
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    move-object v1, p4

    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    invoke-virtual/range {v0 .. v5}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 78
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final save(Ljava/lang/String;Ljava/lang/String;)V
    .registers 11
    .param p1, "key"  # Ljava/lang/String;
    .param p2, "value"  # Ljava/lang/String;

    .line 87
    invoke-virtual {p0, p1}, Lapp/manitux/cloudstream/shared/DomainSettings;->getOverride(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_c

    .line 184
    .local v0, "it":Ljava/lang/String;
    const/4 v1, 0x0

    .line 87
    .local v1, "$i$a$-let-DomainSettings$save$1":I
    sget-object v2, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v2, p1, v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->rememberDomain(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .end local v0  # "it":Ljava/lang/String;
    .end local v1  # "$i$a$-let-DomainSettings$save$1":I
    :cond_c
    if-eqz p2, :cond_15

    move-object v0, p2

    .line 184
    .restart local v0  # "it":Ljava/lang/String;
    const/4 v1, 0x0

    .line 88
    .local v1, "$i$a$-let-DomainSettings$save$2":I
    sget-object v2, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v2, p1, v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->rememberDomain(Ljava/lang/String;Ljava/lang/String;)V

    .line 89
    .end local v0  # "it":Ljava/lang/String;
    .end local v1  # "$i$a$-let-DomainSettings$save$2":I
    :cond_15
    nop

    .line 92
    nop

    .line 89
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_82

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    if-eqz v0, :cond_82

    move-object v1, v0

    .local v1, "$this$save_u24lambda_u242":Landroid/content/SharedPreferences$Editor;
    const/4 v2, 0x0

    .line 90
    .local v2, "$i$a$-apply-DomainSettings$save$3":I
    const-string v3, "toLowerCase(...)"

    const-string v4, "domain_"

    if-nez p2, :cond_47

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_7b

    .line 91
    :cond_47
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move-object v4, p2

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v4}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    new-array v5, v5, [C

    const/16 v6, 0x2f

    const/4 v7, 0x0

    aput-char v6, v5, v7

    invoke-static {v4, v5}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 92
    :goto_7b
    nop

    .line 89
    .end local v1  # "$this$save_u24lambda_u242":Landroid/content/SharedPreferences$Editor;
    .end local v2  # "$i$a$-apply-DomainSettings$save$3":I
    nop

    .line 92
    nop

    .line 89
    nop

    .line 92
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 93
    :cond_82
    return-void
.end method

.method private final selectDomainExtension(Landroid/widget/EditText;)V
    .registers 6
    .param p1, "input"  # Landroid/widget/EditText;

    .line 166
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    if-eqz v0, :cond_b

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    if-nez v0, :cond_10

    const-string v0, ""

    .line 167
    .local v0, "value":Ljava/lang/String;
    :cond_10
    invoke-virtual {p0, v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->domainExtensionRange$FilmMakinesi_debug(Ljava/lang/String;)Lkotlin/ranges/IntRange;

    move-result-object v1

    .line 168
    .local v1, "range":Lkotlin/ranges/IntRange;
    if-nez v1, :cond_1e

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/widget/EditText;->setSelection(I)V

    goto :goto_2b

    .line 169
    :cond_1e
    invoke-virtual {v1}, Lkotlin/ranges/IntRange;->getFirst()I

    move-result v2

    invoke-virtual {v1}, Lkotlin/ranges/IntRange;->getLast()I

    move-result v3

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {p1, v2, v3}, Landroid/widget/EditText;->setSelection(II)V

    .line 170
    :goto_2b
    return-void
.end method

.method private static final showDomainDialog$lambda$0$0(Landroid/widget/EditText;Landroid/view/View;Z)V
    .registers 3
    .param p0, "$this_apply"  # Landroid/widget/EditText;
    .param p2, "focused"  # Z

    .line 109
    if-eqz p2, :cond_7

    sget-object p1, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-direct {p1, p0}, Lapp/manitux/cloudstream/shared/DomainSettings;->selectDomainExtension(Landroid/widget/EditText;)V

    .line 110
    :cond_7
    return-void
.end method

.method private static final showDomainDialog$lambda$2(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Landroid/content/DialogInterface;)V
    .registers 20
    .param p0, "$dialog"  # Landroid/app/AlertDialog;
    .param p1, "$input"  # Landroid/widget/EditText;
    .param p2, "$initialUrl"  # Ljava/lang/String;
    .param p3, "$key"  # Ljava/lang/String;
    .param p4, "$onChanged"  # Lkotlin/jvm/functions/Function1;
    .param p5, "$context"  # Landroid/content/Context;
    .param p6, "$displayName"  # Ljava/lang/String;
    .param p7, "$fallback"  # Ljava/lang/String;
    .param p8, "it"  # Landroid/content/DialogInterface;

    .line 128
    move-object v8, p0

    const/4 v0, -0x1

    invoke-virtual {p0, v0}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v9

    new-instance v10, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;

    move-object v0, v10

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object v7, p0

    invoke-direct/range {v0 .. v7}, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda3;-><init>(Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;)V

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 142
    const/4 v0, -0x3

    invoke-virtual {p0, v0}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v7

    new-instance v9, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda4;

    move-object v0, v9

    move-object v1, p3

    move-object v2, p4

    move-object/from16 v3, p7

    move-object/from16 v4, p5

    move-object/from16 v5, p6

    move-object v6, p0

    invoke-direct/range {v0 .. v6}, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;)V

    invoke-virtual {v7, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 158
    invoke-virtual {p0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_3f

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_3f

    .line 184
    .local v0, "p0":Landroid/view/View;
    const/4 v1, 0x0

    .line 158
    .local v1, "$i$a$-let-DomainSettings$showDomainDialog$1$3":I
    invoke-static {v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog$lambda$2$applyWhiteText(Landroid/view/View;)V

    .line 159
    .end local v0  # "p0":Landroid/view/View;
    .end local v1  # "$i$a$-let-DomainSettings$showDomainDialog$1$3":I
    :cond_3f
    invoke-virtual {p1}, Landroid/widget/EditText;->requestFocus()Z

    .line 160
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    move-object v1, p1

    invoke-direct {v0, p1}, Lapp/manitux/cloudstream/shared/DomainSettings;->selectDomainExtension(Landroid/widget/EditText;)V

    .line 161
    return-void
.end method

.method private static final showDomainDialog$lambda$2$0(Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V
    .registers 16
    .param p0, "$input"  # Landroid/widget/EditText;
    .param p1, "$initialUrl"  # Ljava/lang/String;
    .param p2, "$key"  # Ljava/lang/String;
    .param p3, "$onChanged"  # Lkotlin/jvm/functions/Function1;
    .param p4, "$context"  # Landroid/content/Context;
    .param p5, "$displayName"  # Ljava/lang/String;
    .param p6, "$dialog"  # Landroid/app/AlertDialog;
    .param p7, "it"  # Landroid/view/View;

    .line 129
    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_25

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_25

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_25

    const/4 v2, 0x1

    new-array v2, v2, [C

    const/16 v3, 0x2f

    aput-char v3, v2, v1

    invoke-static {v0, v2}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v0

    goto :goto_26

    :cond_25
    const/4 v0, 0x0

    :goto_26
    if-nez v0, :cond_2a

    const-string v0, ""

    .line 130
    .local v0, "value":Ljava/lang/String;
    :cond_2a
    sget-object v2, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-virtual {v2, v0}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_53

    .line 131
    new-instance v2, Landroid/text/SpannableString;

    const-string v3, "Geçerli bir HTTPS adresi girin"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-direct {v2, v3}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    move-object v3, v2

    .local v3, "$this$showDomainDialog_u24lambda_u242_u240_u240":Landroid/text/SpannableString;
    const/4 v4, 0x0

    .line 132
    .local v4, "$i$a$-apply-DomainSettings$showDomainDialog$1$1$1":I
    new-instance v5, Landroid/text/style/ForegroundColorSpan;

    const/4 v6, -0x1

    invoke-direct {v5, v6}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v3}, Landroid/text/SpannableString;->length()I

    move-result v6

    const/16 v7, 0x21

    invoke-virtual {v3, v5, v1, v6, v7}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 133
    nop

    .line 131
    .end local v3  # "$this$showDomainDialog_u24lambda_u242_u240_u240":Landroid/text/SpannableString;
    .end local v4  # "$i$a$-apply-DomainSettings$showDomainDialog$1$1$1":I
    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {p0, v2}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    .line 134
    return-void

    .line 137
    :cond_53
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_61

    sget-object v2, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v2, p2}, Lapp/manitux/cloudstream/shared/DomainSettings;->getOverride(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_66

    :cond_61
    sget-object v2, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-direct {v2, p2, v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->save(Ljava/lang/String;Ljava/lang/String;)V

    .line 138
    :cond_66
    invoke-interface {p3, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " alan adı kaydedildi"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {p4, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 140
    invoke-virtual {p6}, Landroid/app/AlertDialog;->dismiss()V

    .line 141
    return-void
.end method

.method private static final showDomainDialog$lambda$2$1(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Landroid/app/AlertDialog;Landroid/view/View;)V
    .registers 9
    .param p0, "$key"  # Ljava/lang/String;
    .param p1, "$onChanged"  # Lkotlin/jvm/functions/Function1;
    .param p2, "$fallback"  # Ljava/lang/String;
    .param p3, "$context"  # Landroid/content/Context;
    .param p4, "$displayName"  # Ljava/lang/String;
    .param p5, "$dialog"  # Landroid/app/AlertDialog;
    .param p6, "it"  # Landroid/view/View;

    .line 143
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lapp/manitux/cloudstream/shared/DomainSettings;->save(Ljava/lang/String;Ljava/lang/String;)V

    .line 144
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-virtual {v0, p0, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->cachedDomain(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 145
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " varsayılan adres ayarına döndü"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v1, 0x0

    invoke-static {p3, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 146
    invoke-virtual {p5}, Landroid/app/AlertDialog;->dismiss()V

    .line 147
    return-void
.end method

.method private static final showDomainDialog$lambda$2$applyWhiteText(Landroid/view/View;)V
    .registers 4
    .param p0, "view"  # Landroid/view/View;

    .line 150
    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_11

    .line 151
    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 152
    move-object v0, p0

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHintTextColor(I)V

    .line 154
    :cond_11
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2c

    .line 155
    const/4 v0, 0x0

    .local v0, "index":I
    move-object v1, p0

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    :goto_1d
    if-ge v0, v1, :cond_2c

    move-object v2, p0

    check-cast v2, Landroid/view/ViewGroup;

    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v2}, Lapp/manitux/cloudstream/shared/DomainSettings;->showDomainDialog$lambda$2$applyWhiteText(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1d

    .line 157
    .end local v0  # "index":I
    :cond_2c
    return-void
.end method


# virtual methods
.method public final domainExtensionRange$FilmMakinesi_debug(Ljava/lang/String;)Lkotlin/ranges/IntRange;
    .registers 20
    .param p1, "value"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 172
    move-object/from16 v1, p1

    const/4 v2, 0x0

    :try_start_3
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object/from16 v0, p0

    check-cast v0, Lapp/manitux/cloudstream/shared/DomainSettings;

    .local v0, "$this$domainExtensionRange_u24lambda_u240":Lapp/manitux/cloudstream/shared/DomainSettings;
    const/4 v3, 0x0

    .line 173
    .local v3, "$i$a$-runCatching-DomainSettings$domainExtensionRange$1":I
    sget-object v4, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-virtual {v4, v1}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_13

    return-object v2

    .line 174
    :cond_13
    new-instance v4, Ljava/net/URI;

    invoke-direct {v4, v1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 175
    .local v4, "uri":Ljava/net/URI;
    invoke-virtual {v4}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_1f

    return-object v2

    .line 176
    .local v5, "host":Ljava/lang/String;
    :cond_1f
    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    const/16 v7, 0x3a

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v6, v7, v9, v8, v2}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_94

    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    .local v6, "$this$all$iv":Ljava/lang/CharSequence;
    const/4 v7, 0x0

    .line 187
    .local v7, "$i$f$all":I
    const/4 v8, 0x0

    :goto_31
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v10

    const/4 v11, 0x1

    if-ge v8, v10, :cond_52

    invoke-interface {v6, v8}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v10

    .local v10, "element$iv":C
    move v12, v10

    .local v12, "it":C
    const/4 v13, 0x0

    .line 176
    .local v13, "$i$a$-all-DomainSettings$domainExtensionRange$1$1":I
    invoke-static {v12}, Ljava/lang/Character;->isDigit(C)Z

    move-result v14

    if-nez v14, :cond_4b

    const/16 v14, 0x2e

    if-ne v12, v14, :cond_49

    goto :goto_4b

    :cond_49
    const/4 v12, 0x0

    goto :goto_4c

    :cond_4b
    :goto_4b
    const/4 v12, 0x1

    .line 187
    .end local v12  # "it":C
    .end local v13  # "$i$a$-all-DomainSettings$domainExtensionRange$1$1":I
    :goto_4c
    if-nez v12, :cond_4f

    goto :goto_53

    .end local v10  # "element$iv":C
    :cond_4f
    add-int/lit8 v8, v8, 0x1

    goto :goto_31

    .line 188
    :cond_52
    const/4 v9, 0x1

    .line 176
    .end local v6  # "$this$all$iv":Ljava/lang/CharSequence;
    .end local v7  # "$i$f$all":I
    :goto_53
    if-eqz v9, :cond_56

    goto :goto_94

    .line 177
    :cond_56
    move-object v12, v5

    check-cast v12, Ljava/lang/CharSequence;

    const/16 v16, 0x6

    const/16 v17, 0x0

    const/16 v13, 0x2e

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Lkotlin/text/StringsKt;->lastIndexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v6

    .line 178
    .local v6, "dot":I
    if-ltz v6, :cond_93

    move-object v7, v5

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Lkotlin/text/StringsKt;->getLastIndex(Ljava/lang/CharSequence;)I

    move-result v7

    if-ne v6, v7, :cond_71

    goto :goto_93

    .line 179
    :cond_71
    move-object v12, v1

    check-cast v12, Ljava/lang/CharSequence;

    const-string v13, "://"

    const/16 v16, 0x6

    const/16 v17, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;Ljava/lang/String;IZILjava/lang/Object;)I

    move-result v7

    add-int/lit8 v7, v7, 0x3

    .line 180
    .local v7, "start":I
    add-int v8, v7, v6

    add-int/2addr v8, v11

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v9

    add-int/2addr v9, v7

    invoke-static {v8, v9}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v8

    .line 172
    .end local v0  # "$this$domainExtensionRange_u24lambda_u240":Lapp/manitux/cloudstream/shared/DomainSettings;
    .end local v3  # "$i$a$-runCatching-DomainSettings$domainExtensionRange$1":I
    .end local v4  # "uri":Ljava/net/URI;
    .end local v5  # "host":Ljava/lang/String;
    .end local v6  # "dot":I
    .end local v7  # "start":I
    invoke-static {v8}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_92
    .catchall {:try_start_3 .. :try_end_92} :catchall_95

    goto :goto_a0

    .line 178
    .restart local v0  # "$this$domainExtensionRange_u24lambda_u240":Lapp/manitux/cloudstream/shared/DomainSettings;
    .restart local v3  # "$i$a$-runCatching-DomainSettings$domainExtensionRange$1":I
    .restart local v4  # "uri":Ljava/net/URI;
    .restart local v5  # "host":Ljava/lang/String;
    .restart local v6  # "dot":I
    :cond_93
    :goto_93
    return-object v2

    .line 176
    .end local v6  # "dot":I
    :cond_94
    :goto_94
    return-object v2

    .line 172
    .end local v0  # "$this$domainExtensionRange_u24lambda_u240":Lapp/manitux/cloudstream/shared/DomainSettings;
    .end local v3  # "$i$a$-runCatching-DomainSettings$domainExtensionRange$1":I
    .end local v4  # "uri":Ljava/net/URI;
    .end local v5  # "host":Ljava/lang/String;
    :catchall_95
    move-exception v0

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 181
    :goto_a0
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a7

    goto :goto_a8

    :cond_a7
    move-object v2, v0

    :goto_a8
    check-cast v2, Lkotlin/ranges/IntRange;

    return-object v2
.end method

.method public final getOverride(Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 36
    nop

    .line 39
    nop

    .line 38
    nop

    .line 37
    nop

    .line 35
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->preferences:Landroid/content/SharedPreferences;

    .line 36
    const/4 v1, 0x0

    if-eqz v0, :cond_57

    .line 35
    nop

    .line 36
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "domain_"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "toLowerCase(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 37
    if-eqz v0, :cond_57

    .line 35
    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 37
    nop

    .line 38
    if-eqz v0, :cond_57

    .line 35
    nop

    .line 38
    const/4 v2, 0x1

    new-array v2, v2, [C

    const/16 v3, 0x2f

    const/4 v4, 0x0

    aput-char v3, v2, v4

    invoke-static {v0, v2}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v0

    .line 39
    if-eqz v0, :cond_57

    .line 35
    nop

    .line 39
    sget-object v2, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    move-object v3, v0

    .line 184
    .local v3, "p0":Ljava/lang/String;
    const/4 v4, 0x0

    .line 39
    .local v4, "$i$a$-takeIf-DomainSettings$getOverride$1":I
    invoke-virtual {v2, v3}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v2

    .end local v3  # "p0":Ljava/lang/String;
    .end local v4  # "$i$a$-takeIf-DomainSettings$getOverride$1":I
    if-eqz v2, :cond_58

    move-object v1, v0

    goto :goto_58

    .line 36
    :cond_57
    nop

    .line 39
    :cond_58
    :goto_58
    return-object v1
.end method

.method public final initialize(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 32
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "manitux_plugin_domains"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    sput-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->preferences:Landroid/content/SharedPreferences;

    .line 33
    return-void
.end method

.method public final installIfSupported(Lcom/lagradost/cloudstream3/plugins/Plugin;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Z
    .registers 20
    .param p1, "plugin"  # Lcom/lagradost/cloudstream3/plugins/Plugin;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "displayName"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p5, "onChanged"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/lagradost/cloudstream3/plugins/Plugin;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 69
    move-object/from16 v1, p3

    const-string v2, " ayar API\'si bu Cloudstream sürümünde bulunmuyor"

    const-string v3, "Manitux_DomainSettings"

    .line 70
    const/4 v4, 0x0

    :try_start_7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getMethods()[Ljava/lang/reflect/Method;

    move-result-object v0

    .local v0, "$this$firstOrNull$iv":[Ljava/lang/Object;
    const/4 v5, 0x0

    .line 185
    .local v5, "$i$f$firstOrNull":I
    array-length v6, v0

    const/4 v7, 0x0

    :goto_12
    const/4 v8, 0x1

    if-ge v7, v6, :cond_35

    aget-object v9, v0, v7

    .local v9, "element$iv":Ljava/lang/Object;
    move-object v10, v9

    .local v10, "it":Ljava/lang/reflect/Method;
    const/4 v11, 0x0

    .line 71
    .local v11, "$i$a$-firstOrNull-DomainSettings$installIfSupported$setter$1":I
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v12

    const-string v13, "setOpenSettings"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_2e

    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v12

    array-length v12, v12

    if-ne v12, v8, :cond_2e

    const/4 v10, 0x1

    goto :goto_2f

    :cond_2e
    const/4 v10, 0x0

    .line 185
    .end local v10  # "it":Ljava/lang/reflect/Method;
    .end local v11  # "$i$a$-firstOrNull-DomainSettings$installIfSupported$setter$1":I
    :goto_2f
    if-eqz v10, :cond_32

    goto :goto_36

    .end local v9  # "element$iv":Ljava/lang/Object;
    :cond_32
    add-int/lit8 v7, v7, 0x1

    goto :goto_12

    .line 186
    :cond_35
    const/4 v9, 0x0

    .line 70
    .end local v0  # "$this$firstOrNull$iv":[Ljava/lang/Object;
    .end local v5  # "$i$f$firstOrNull":I
    :goto_36
    if-nez v9, :cond_51

    .line 72
    move-object v0, p0

    check-cast v0, Lapp/manitux/cloudstream/shared/DomainSettings;

    .local v0, "$this$installIfSupported_u24lambda_u241":Lapp/manitux/cloudstream/shared/DomainSettings;
    const/4 v5, 0x0

    .line 73
    .local v5, "$i$a$-run-DomainSettings$installIfSupported$setter$2":I
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v3, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 74
    return v4

    .line 70
    .end local v0  # "$this$installIfSupported_u24lambda_u241":Lapp/manitux/cloudstream/shared/DomainSettings;
    .end local v5  # "$i$a$-run-DomainSettings$installIfSupported$setter$2":I
    :cond_51
    move-object v0, v9

    .line 76
    .local v0, "setter":Ljava/lang/reflect/Method;
    new-instance v5, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda0;
    :try_end_54
    .catchall {:try_start_7 .. :try_end_54} :catchall_6c

    move-object/from16 v6, p2

    move-object/from16 v7, p4

    move-object/from16 v9, p5

    :try_start_5a
    invoke-direct {v5, v6, v1, v7, v9}, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 79
    .local v5, "callback":Lkotlin/jvm/functions/Function1;
    new-array v10, v8, [Ljava/lang/Object;

    aput-object v5, v10, v4
    :try_end_61
    .catchall {:try_start_5a .. :try_end_61} :catchall_69

    move-object v11, p1

    :try_start_62
    invoke-virtual {v0, p1, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_65
    .catchall {:try_start_62 .. :try_end_65} :catchall_67

    .line 80
    const/4 v4, 0x1

    .end local v0  # "setter":Ljava/lang/reflect/Method;
    .end local v5  # "callback":Lkotlin/jvm/functions/Function1;
    goto :goto_89

    .line 81
    :catchall_67
    move-exception v0

    goto :goto_74

    :catchall_69
    move-exception v0

    move-object v11, p1

    goto :goto_74

    :catchall_6c
    move-exception v0

    move-object v11, p1

    move-object/from16 v6, p2

    move-object/from16 v7, p4

    move-object/from16 v9, p5

    .line 82
    .local v0, "error":Ljava/lang/Throwable;
    :goto_74
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 83
    nop

    .line 84
    .end local v0  # "error":Ljava/lang/Throwable;
    :goto_89
    return v4
.end method

.method public final declared-synchronized knownDomains(Ljava/lang/String;)Ljava/util/Set;
    .registers 7
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    monitor-enter p0

    .line 43
    :try_start_1
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toLowerCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .local v0, "normalized":Ljava/lang/String;
    sget-object v1, Lapp/manitux/cloudstream/shared/DomainSettings;->domainHistory:Ljava/util/Map;

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Set;

    if-nez v1, :cond_1a

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object v1

    .line 45
    .end local p0  # "this":Lapp/manitux/cloudstream/shared/DomainSettings;
    :cond_1a
    sget-object v2, Lapp/manitux/cloudstream/shared/DomainSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v2, :cond_3a

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "history_"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v2

    goto :goto_3b

    :cond_3a
    const/4 v2, 0x0

    :goto_3b
    if-nez v2, :cond_41

    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object v2

    :cond_41
    check-cast v2, Ljava/lang/Iterable;

    .line 44
    invoke-static {v1, v2}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v1
    :try_end_47
    .catchall {:try_start_1 .. :try_end_47} :catchall_49

    monitor-exit p0

    return-object v1

    .line 42
    .end local v0  # "normalized":Ljava/lang/String;
    .end local p1  # "key":Ljava/lang/String;
    :catchall_49
    move-exception p1

    :try_start_4a
    monitor-exit p0
    :try_end_4b
    .catchall {:try_start_4a .. :try_end_4b} :catchall_49

    throw p1
.end method

.method public final declared-synchronized rememberDomain(Ljava/lang/String;Ljava/lang/String;)V
    .registers 9
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "domain"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    monitor-enter p0

    .line 50
    :try_start_1
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-virtual {v0, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_67

    if-nez v0, :cond_b

    monitor-exit p0

    return-void

    .line 51
    :cond_b
    :try_start_b
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toLowerCase(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    .local v0, "normalized":Ljava/lang/String;
    invoke-virtual {p0, v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->knownDomains(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v1

    .line 53
    .local v1, "known":Ljava/util/Set;
    const/4 v2, 0x1

    new-array v3, v2, [C

    const/4 v4, 0x0

    const/16 v5, 0x2f

    aput-char v5, v3, v4

    invoke-static {p2, v3}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3
    :try_end_2a
    .catchall {:try_start_b .. :try_end_2a} :catchall_67

    if-eqz v3, :cond_2e

    monitor-exit p0

    return-void

    .line 54
    :cond_2e
    :try_start_2e
    new-array v2, v2, [C

    aput-char v5, v2, v4

    invoke-static {p2, v2}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    .line 55
    .local v2, "updated":Ljava/util/Set;
    sget-object v3, Lapp/manitux/cloudstream/shared/DomainSettings;->domainHistory:Ljava/util/Map;

    invoke-interface {v3, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    sget-object v3, Lapp/manitux/cloudstream/shared/DomainSettings;->preferences:Landroid/content/SharedPreferences;

    if-eqz v3, :cond_65

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    if-eqz v3, :cond_65

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "history_"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    if-eqz v3, :cond_65

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_65
    .catchall {:try_start_2e .. :try_end_65} :catchall_67

    .line 57
    .end local p0  # "this":Lapp/manitux/cloudstream/shared/DomainSettings;
    :cond_65
    monitor-exit p0

    return-void

    .line 49
    .end local v0  # "normalized":Ljava/lang/String;
    .end local v1  # "known":Ljava/util/Set;
    .end local v2  # "updated":Ljava/util/Set;
    .end local p1  # "key":Ljava/lang/String;
    .end local p2  # "domain":Ljava/lang/String;
    :catchall_67
    move-exception p1

    :try_start_68
    monitor-exit p0
    :try_end_69
    .catchall {:try_start_68 .. :try_end_69} :catchall_67

    throw p1
.end method

.method public final showDomainDialog(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .registers 23
    .param p1, "context"  # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "displayName"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p5, "onChanged"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 102
    move-object/from16 v9, p1

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v10, v0, Landroid/util/DisplayMetrics;->density:F

    .line 103
    .local v10, "density":F
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    move-object/from16 v11, p2

    move-object/from16 v12, p4

    invoke-virtual {v0, v11, v12}, Lapp/manitux/cloudstream/shared/RemoteConfig;->cachedDomain(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 104
    .local v13, "initialUrl":Ljava/lang/String;
    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, v9}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showDomainDialog_u24lambda_u240":Landroid/widget/EditText;
    const/4 v2, 0x0

    .line 105
    .local v2, "$i$a$-apply-DomainSettings$showDomainDialog$input$1":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 106
    const/16 v3, 0x11

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setInputType(I)V

    .line 107
    move-object v3, v13

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 108
    new-instance v3, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda1;

    invoke-direct {v3, v1}, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda1;-><init>(Landroid/widget/EditText;)V

    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 111
    nop

    .line 104
    .end local v1  # "$this$showDomainDialog_u24lambda_u240":Landroid/widget/EditText;
    .end local v2  # "$i$a$-apply-DomainSettings$showDomainDialog$input$1":I
    move-object v14, v0

    .line 112
    .local v14, "input":Landroid/widget/EditText;
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, v9}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v1, v0

    .local v1, "$this$showDomainDialog_u24lambda_u241":Landroid/widget/FrameLayout;
    const/4 v2, 0x0

    .line 113
    .local v2, "$i$a$-apply-DomainSettings$showDomainDialog$container$1":I
    const/16 v3, 0x18

    int-to-float v3, v3

    mul-float v3, v3, v10

    float-to-int v3, v3

    .line 114
    .local v3, "horizontal":I
    move-object v4, v14

    check-cast v4, Landroid/view/View;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v6, v5

    .local v6, "$this$showDomainDialog_u24lambda_u241_u240":Landroid/widget/FrameLayout$LayoutParams;
    const/4 v7, 0x0

    .line 115
    .local v7, "$i$a$-apply-DomainSettings$showDomainDialog$container$1$1":I
    iput v3, v6, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 116
    iput v3, v6, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 117
    nop

    .end local v6  # "$this$showDomainDialog_u24lambda_u241_u240":Landroid/widget/FrameLayout$LayoutParams;
    .end local v7  # "$i$a$-apply-DomainSettings$showDomainDialog$container$1$1":I
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 114
    check-cast v5, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v1, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 118
    nop

    .line 112
    .end local v1  # "$this$showDomainDialog_u24lambda_u241":Landroid/widget/FrameLayout;
    .end local v2  # "$i$a$-apply-DomainSettings$showDomainDialog$container$1":I
    .end local v3  # "horizontal":I
    move-object v15, v0

    .line 119
    .local v15, "container":Landroid/widget/FrameLayout;
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, v9}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 120
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v8, p3

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " alan adı"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 121
    const-string v1, "Adresteki uzantıyı değiştirip kaydedebilirsiniz. Otomatik adres takibi için ‘Repodan takip et’ seçeneğini kullanın."

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 122
    move-object v1, v15

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 123
    const-string v1, "Kaydet"

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 124
    const-string v1, "Repodan takip et"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 125
    const-string v1, "İptal"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 126
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    .line 119
    move-object v7, v0

    .line 127
    .local v7, "dialog":Landroid/app/AlertDialog;
    new-instance v6, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;

    move-object v0, v6

    move-object v1, v7

    move-object v2, v14

    move-object v3, v13

    move-object/from16 v4, p2

    move-object/from16 v5, p5

    move-object v9, v6

    move-object/from16 v6, p1

    move/from16 v16, v10

    move-object v10, v7

    .end local v7  # "dialog":Landroid/app/AlertDialog;
    .local v10, "dialog":Landroid/app/AlertDialog;
    .local v16, "density":F
    move-object/from16 v7, p3

    move-object/from16 v8, p4

    invoke-direct/range {v0 .. v8}, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda2;-><init>(Landroid/app/AlertDialog;Landroid/widget/EditText;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v10, v9}, Landroid/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 162
    invoke-virtual {v10}, Landroid/app/AlertDialog;->show()V

    .line 163
    return-void
.end method
