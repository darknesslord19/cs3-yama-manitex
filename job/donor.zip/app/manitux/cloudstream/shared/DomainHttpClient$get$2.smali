.class final Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DomainHttpClient.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lapp/manitux/cloudstream/shared/DomainHttpClient;->get(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Ljava/lang/String;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lcom/lagradost/nicehttp/NiceResponse;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"
    }
    d2 = {
        "<anonymous>",
        "Lcom/lagradost/nicehttp/NiceResponse;",
        "target",
        ""
    }
    k = 0x3
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "app.manitux.cloudstream.shared.DomainHttpClient$get$2"
    f = "DomainHttpClient.kt"
    i = {
        0x0
    }
    l = {
        0x1c
    }
    m = "invokeSuspend"
    n = {
        "target"
    }
    nl = {
        0x1e
    }
    s = {
        "L$0"
    }
    v = 0x2
.end annotation


# instance fields
.field final synthetic $cookies:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $headerOrigin:Ljava/lang/String;

.field final synthetic $headers:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $params:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $referer:Ljava/lang/String;

.field synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lapp/manitux/cloudstream/shared/DomainHttpClient;


# direct methods
.method constructor <init>(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lapp/manitux/cloudstream/shared/DomainHttpClient;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->this$0:Lapp/manitux/cloudstream/shared/DomainHttpClient;

    iput-object p2, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headers:Ljava/util/Map;

    iput-object p3, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headerOrigin:Ljava/lang/String;

    iput-object p4, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$referer:Ljava/lang/String;

    iput-object p5, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$params:Ljava/util/Map;

    iput-object p6, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$cookies:Ljava/util/Map;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p7}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v8, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;

    iget-object v1, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->this$0:Lapp/manitux/cloudstream/shared/DomainHttpClient;

    iget-object v2, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headers:Ljava/util/Map;

    iget-object v3, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headerOrigin:Ljava/lang/String;

    iget-object v4, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$referer:Ljava/lang/String;

    iget-object v5, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$params:Ljava/util/Map;

    iget-object v6, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$cookies:Ljava/util/Map;

    move-object v0, v8

    move-object v7, p2

    invoke-direct/range {v0 .. v7}, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;-><init>(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)V

    iput-object p1, v8, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->L$0:Ljava/lang/Object;

    check-cast v8, Lkotlin/coroutines/Continuation;

    return-object v8
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Ljava/lang/String;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->invoke(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/lagradost/nicehttp/NiceResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 22
    .param p1, "$result"  # Ljava/lang/Object;

    move-object/from16 v0, p0

    iget-object v1, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->L$0:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    .local v1, "target":Ljava/lang/String;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v7

    .line 27
    iget v2, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->label:I

    packed-switch v2, :pswitch_data_70

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_17  #0x1
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object/from16 v2, p1

    goto :goto_6f

    :pswitch_1d  #0x0
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 28
    invoke-static {}, Lcom/lagradost/cloudstream3/MainActivityKt;->getApp()Lcom/lagradost/nicehttp/Requests;

    move-result-object v2

    iget-object v3, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->this$0:Lapp/manitux/cloudstream/shared/DomainHttpClient;

    iget-object v4, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headers:Ljava/util/Map;

    iget-object v5, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headerOrigin:Ljava/lang/String;

    invoke-static {v3, v4, v5, v1}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->access$requestHeaders(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v4

    .line 29
    iget-object v3, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->this$0:Lapp/manitux/cloudstream/shared/DomainHttpClient;

    iget-object v5, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$referer:Ljava/lang/String;

    invoke-static {v3, v5, v1}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->access$rebaseReferer(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$params:Ljava/util/Map;

    .line 30
    sget-object v3, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainFailurePolicy;

    iget-object v8, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$headerOrigin:Ljava/lang/String;

    invoke-virtual {v3, v8, v1}, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->sameOrigin$FilmMakinesi_debug(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_45

    iget-object v3, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->$cookies:Ljava/util/Map;

    goto :goto_49

    :cond_45
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v3

    :goto_49
    move-object/from16 v19, v3

    .line 28
    move-object/from16 v16, v0

    check-cast v16, Lkotlin/coroutines/Continuation;

    invoke-static {v1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    iput-object v3, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->L$0:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;->label:I

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v17, 0xfe0

    const/16 v18, 0x0

    move-object v3, v1

    move-object v0, v7

    move-object/from16 v7, v19

    invoke-static/range {v2 .. v18}, Lcom/lagradost/nicehttp/Requests;->get$default(Lcom/lagradost/nicehttp/Requests;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;ZILjava/util/concurrent/TimeUnit;JLokhttp3/Interceptor;ZLcom/lagradost/nicehttp/ResponseParser;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v0, :cond_6f

    .line 27
    return-object v0

    .line 30
    :cond_6f
    :goto_6f
    return-object v2

    :pswitch_data_70
    .packed-switch 0x0
        :pswitch_1d  #00000000
        :pswitch_17  #00000001
    .end packed-switch
.end method
