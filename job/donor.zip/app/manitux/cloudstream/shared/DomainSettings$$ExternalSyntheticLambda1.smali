.class public final synthetic Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x12
    versionHash = "7de78e4c4546435adeebf26ef4b0cc5c4f405847ffd476305b2b34259a231191"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda1;->f$0:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .registers 4

    .line 0
    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainSettings$$ExternalSyntheticLambda1;->f$0:Landroid/widget/EditText;

    invoke-static {v0, p1, p2}, Lapp/manitux/cloudstream/shared/DomainSettings;->$r8$lambda$jrk7IXfNC_qE2OgYJHnP0JYjO7A(Landroid/widget/EditText;Landroid/view/View;Z)V

    return-void
.end method
