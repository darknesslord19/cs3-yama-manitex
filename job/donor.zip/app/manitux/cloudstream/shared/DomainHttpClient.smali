.class public final Lapp/manitux/cloudstream/shared/DomainHttpClient;
.super Ljava/lang/Object;
.source "DomainHttpClient.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDomainHttpClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DomainHttpClient.kt\napp/manitux/cloudstream/shared/DomainHttpClient\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,99:1\n1807#2,3:100\n1266#2,4:113\n1#3:103\n491#4,7:104\n466#4:111\n415#4:112\n*S KotlinDebug\n*F\n+ 1 DomainHttpClient.kt\napp/manitux/cloudstream/shared/DomainHttpClient\n*L\n80#1:100,3\n92#1:113,4\n91#1:104,7\n92#1:111\n92#1:112\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u0006\u0012\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\b¢\u0006\u0004\b\n\u0010\u000bJ\u000e\u0010\f\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\u0003Jd\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\u00032\u0014\b\u0002\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00112\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u00032\u0014\b\u0002\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00112\u0014\b\u0002\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0011H\u0086@¢\u0006\u0002\u0010\u0015JN\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\u00032\u0014\b\u0002\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00112\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u00032\u0014\b\u0002\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0011H\u0086@¢\u0006\u0002\u0010\u0018J:\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\u00032\"\u0010\u001a\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0003\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u001c\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u001bH\u0082@¢\u0006\u0002\u0010\u001dJ\u0018\u0010\u001e\u001a\u00020\u001f2\u0006\u0010\r\u001a\u00020\u00032\u0006\u0010 \u001a\u00020\u0003H\u0002J\u001c\u0010!\u001a\u0004\u0018\u00010\u00032\b\u0010\u0012\u001a\u0004\u0018\u00010\u00032\u0006\u0010\"\u001a\u00020\u0003H\u0002J8\u0010#\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00112\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00112\u0006\u0010$\u001a\u00020\u00032\u0006\u0010\"\u001a\u00020\u0003H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006%"
    }
    d2 = {
        "Lapp/manitux/cloudstream/shared/DomainHttpClient;",
        "",
        "key",
        "",
        "fallback",
        "currentDomain",
        "Lkotlin/Function0;",
        "applyDomain",
        "Lkotlin/Function1;",
        "",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V",
        "siteUrl",
        "url",
        "get",
        "Lcom/lagradost/nicehttp/NiceResponse;",
        "headers",
        "",
        "referer",
        "params",
        "cookies",
        "(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "post",
        "data",
        "(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "request",
        "fetch",
        "Lkotlin/Function2;",
        "Lkotlin/coroutines/Continuation;",
        "(Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "belongsToSite",
        "",
        "current",
        "rebaseReferer",
        "target",
        "requestHeaders",
        "original",
        "FilmMakinesi_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nDomainHttpClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DomainHttpClient.kt\napp/manitux/cloudstream/shared/DomainHttpClient\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,99:1\n1807#2,3:100\n1266#2,4:113\n1#3:103\n491#4,7:104\n466#4:111\n415#4:112\n*S KotlinDebug\n*F\n+ 1 DomainHttpClient.kt\napp/manitux/cloudstream/shared/DomainHttpClient\n*L\n80#1:100,3\n92#1:113,4\n91#1:104,7\n92#1:111\n92#1:112\n*E\n"
    }
.end annotation


# instance fields
.field private final applyDomain:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final currentDomain:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final fallback:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private final key:Ljava/lang/String;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V
    .registers 5
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "currentDomain"  # Lkotlin/jvm/functions/Function0;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4, "applyDomain"  # Lkotlin/jvm/functions/Function1;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput-object p1, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    .line 13
    iput-object p2, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    .line 14
    iput-object p3, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    .line 15
    iput-object p4, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->applyDomain:Lkotlin/jvm/functions/Function1;

    .line 11
    return-void
.end method

.method public static final synthetic access$rebaseReferer(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    .param p0, "$this"  # Lapp/manitux/cloudstream/shared/DomainHttpClient;
    .param p1, "referer"  # Ljava/lang/String;
    .param p2, "target"  # Ljava/lang/String;

    .line 11
    invoke-direct {p0, p1, p2}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->rebaseReferer(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$request(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .param p0, "$this"  # Lapp/manitux/cloudstream/shared/DomainHttpClient;
    .param p1, "url"  # Ljava/lang/String;
    .param p2, "fetch"  # Lkotlin/jvm/functions/Function2;
    .param p3, "$completion"  # Lkotlin/coroutines/Continuation;

    .line 11
    invoke-direct {p0, p1, p2, p3}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->request(Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$requestHeaders(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;
    .registers 5
    .param p0, "$this"  # Lapp/manitux/cloudstream/shared/DomainHttpClient;
    .param p1, "headers"  # Ljava/util/Map;
    .param p2, "original"  # Ljava/lang/String;
    .param p3, "target"  # Ljava/lang/String;

    .line 11
    invoke-direct {p0, p1, p2, p3}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->requestHeaders(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method

.method private final belongsToSite(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 11
    .param p1, "url"  # Ljava/lang/String;
    .param p2, "current"  # Ljava/lang/String;

    .line 80
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    iget-object v1, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lapp/manitux/cloudstream/shared/DomainSettings;->knownDomains(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v0

    iget-object v1, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    invoke-static {v0, v1}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    invoke-static {v0, p2}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 100
    .local v1, "$i$f$any":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x0

    if-eqz v2, :cond_24

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_24

    goto :goto_41

    .line 101
    :cond_24
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_28
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_40

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ljava/lang/String;

    .local v5, "it":Ljava/lang/String;
    const/4 v6, 0x0

    .line 80
    .local v6, "$i$a$-any-DomainHttpClient$belongsToSite$1":I
    sget-object v7, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainFailurePolicy;

    invoke-virtual {v7, p1, v5}, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->sameOrigin$FilmMakinesi_debug(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    .line 101
    .end local v5  # "it":Ljava/lang/String;
    .end local v6  # "$i$a$-any-DomainHttpClient$belongsToSite$1":I
    if-eqz v5, :cond_28

    const/4 v3, 0x1

    goto :goto_41

    .line 102
    .end local v4  # "element$iv":Ljava/lang/Object;
    :cond_40
    nop

    .line 80
    .end local v0  # "$this$any$iv":Ljava/lang/Iterable;
    .end local v1  # "$i$f$any":I
    :goto_41
    return v3
.end method

.method public static synthetic get$default(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .line 19
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_a

    .line 21
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object p2

    move-object v2, p2

    goto :goto_b

    .line 19
    :cond_a
    move-object v2, p2

    :goto_b
    and-int/lit8 p2, p7, 0x4

    if-eqz p2, :cond_12

    .line 22
    const/4 p3, 0x0

    move-object v3, p3

    goto :goto_13

    .line 19
    :cond_12
    move-object v3, p3

    :goto_13
    and-int/lit8 p2, p7, 0x8

    if-eqz p2, :cond_1d

    .line 23
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object p4

    move-object v4, p4

    goto :goto_1e

    .line 19
    :cond_1d
    move-object v4, p4

    :goto_1e
    and-int/lit8 p2, p7, 0x10

    if-eqz p2, :cond_28

    .line 24
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object p5

    move-object v5, p5

    goto :goto_29

    .line 19
    :cond_28
    move-object v5, p5

    :goto_29
    move-object v0, p0

    move-object v1, p1

    move-object v6, p6

    invoke-virtual/range {v0 .. v6}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->get(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic post$default(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 35
    and-int/lit8 p7, p6, 0x2

    if-eqz p7, :cond_a

    .line 37
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object p2

    move-object v2, p2

    goto :goto_b

    .line 35
    :cond_a
    move-object v2, p2

    :goto_b
    and-int/lit8 p2, p6, 0x4

    if-eqz p2, :cond_12

    .line 38
    const/4 p3, 0x0

    move-object v3, p3

    goto :goto_13

    .line 35
    :cond_12
    move-object v3, p3

    :goto_13
    and-int/lit8 p2, p6, 0x8

    if-eqz p2, :cond_1d

    .line 39
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object p4

    move-object v4, p4

    goto :goto_1e

    .line 35
    :cond_1d
    move-object v4, p4

    :goto_1e
    move-object v0, p0

    move-object v1, p1

    move-object v5, p5

    invoke-virtual/range {v0 .. v5}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->post(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method private final rebaseReferer(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    .param p1, "referer"  # Ljava/lang/String;
    .param p2, "target"  # Ljava/lang/String;

    .line 83
    if-eqz p1, :cond_41

    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-direct {p0, p2, v0}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->belongsToSite(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_11

    goto :goto_41

    .line 84
    :cond_11
    new-instance v0, Ljava/net/URI;

    invoke-direct {v0, p2}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 103
    .local v0, "it":Ljava/net/URI;
    const/4 v1, 0x0

    .line 84
    .local v1, "$i$a$-let-DomainHttpClient$rebaseReferer$origin$1":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "://"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/net/URI;->getRawAuthority()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 85
    .end local v1  # "$i$a$-let-DomainHttpClient$rebaseReferer$origin$1":I
    .local v0, "origin":Ljava/lang/String;
    sget-object v1, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    iget-object v2, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    iget-object v3, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v1, p1, v2, v0, v3}, Lapp/manitux/cloudstream/shared/RemoteConfig;->rebaseSiteUrl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 83
    .end local v0  # "origin":Ljava/lang/String;
    :cond_41
    :goto_41
    return-object p1
.end method

.method private final request(Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 21
    .param p1, "url"  # Ljava/lang/String;
    .param p2, "fetch"  # Lkotlin/jvm/functions/Function2;
    .param p3, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/lagradost/nicehttp/NiceResponse;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/lagradost/nicehttp/NiceResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    instance-of v0, v4, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;

    if-eqz v0, :cond_1c

    move-object v0, v4

    check-cast v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;

    iget v5, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    const/high16 v6, -0x80000000

    and-int/2addr v5, v6

    if-eqz v5, :cond_1c

    iget v5, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    sub-int/2addr v5, v6

    iput v5, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    goto :goto_21

    :cond_1c
    new-instance v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;

    invoke-direct {v0, v1, v4}, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;-><init>(Lapp/manitux/cloudstream/shared/DomainHttpClient;Lkotlin/coroutines/Continuation;)V

    :goto_21
    move-object v5, v0

    .local v5, "$continuation":Lkotlin/coroutines/Continuation;
    iget-object v6, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->result:Ljava/lang/Object;

    .local v6, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v7

    .line 48
    iget v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    packed-switch v0, :pswitch_data_1ee

    .end local v5  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v6  # "$result":Ljava/lang/Object;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local v5  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v6  # "$result":Ljava/lang/Object;
    :pswitch_35  #0x4
    iget-boolean v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    .local v0, "siteRequest":Z
    iget-object v7, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$7:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    .local v7, "retryUrl":Ljava/lang/String;
    iget-object v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$6:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    .local v8, "updated":Ljava/lang/String;
    iget-object v9, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$5:Ljava/lang/Object;

    check-cast v9, Ljava/lang/Exception;

    .local v9, "failure":Ljava/lang/Exception;
    iget-object v10, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$4:Ljava/lang/Object;

    check-cast v10, Lcom/lagradost/nicehttp/NiceResponse;

    .local v10, "response":Lcom/lagradost/nicehttp/NiceResponse;
    iget-object v11, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$3:Ljava/lang/Object;

    check-cast v11, Ljava/lang/String;

    .local v11, "initialUrl":Ljava/lang/String;
    iget-object v12, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    check-cast v12, Ljava/lang/String;

    .local v12, "initialDomain":Ljava/lang/String;
    iget-object v13, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    move-object v3, v13

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .local v3, "fetch":Lkotlin/jvm/functions/Function2;
    iget-object v13, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    move-object v2, v13

    check-cast v2, Ljava/lang/String;

    .end local p1  # "url":Ljava/lang/String;
    .local v2, "url":Ljava/lang/String;
    invoke-static {v6}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v14, v6

    goto/16 :goto_1d8

    .end local v0  # "siteRequest":Z
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .end local v7  # "retryUrl":Ljava/lang/String;
    .end local v8  # "updated":Ljava/lang/String;
    .end local v9  # "failure":Ljava/lang/Exception;
    .end local v10  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .end local v11  # "initialUrl":Ljava/lang/String;
    .end local v12  # "initialDomain":Ljava/lang/String;
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :pswitch_5f  #0x3
    iget-boolean v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    .restart local v0  # "siteRequest":Z
    iget-object v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$5:Ljava/lang/Object;

    check-cast v8, Ljava/lang/Exception;

    .local v8, "failure":Ljava/lang/Exception;
    iget-object v9, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$4:Ljava/lang/Object;

    check-cast v9, Lcom/lagradost/nicehttp/NiceResponse;

    .local v9, "response":Lcom/lagradost/nicehttp/NiceResponse;
    iget-object v10, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$3:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    .local v10, "initialUrl":Ljava/lang/String;
    iget-object v11, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    check-cast v11, Ljava/lang/String;

    .local v11, "initialDomain":Ljava/lang/String;
    iget-object v12, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    move-object v3, v12

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    iget-object v12, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    move-object v2, v12

    check-cast v2, Ljava/lang/String;

    .end local p1  # "url":Ljava/lang/String;
    .restart local v2  # "url":Ljava/lang/String;
    invoke-static {v6}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v12, v11

    move-object v11, v10

    move-object v10, v9

    move-object v9, v8

    move v8, v0

    move-object v0, v6

    goto/16 :goto_15a

    .end local v0  # "siteRequest":Z
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .end local v8  # "failure":Ljava/lang/Exception;
    .end local v9  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .end local v10  # "initialUrl":Ljava/lang/String;
    .end local v11  # "initialDomain":Ljava/lang/String;
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :pswitch_86  #0x2
    iget-boolean v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    .local v8, "siteRequest":Z
    const/4 v9, 0x0

    .local v9, "failure":Ljava/lang/Exception;
    const/4 v10, 0x0

    .local v10, "response":Lcom/lagradost/nicehttp/NiceResponse;
    iget-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$3:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Ljava/lang/String;

    .local v11, "initialUrl":Ljava/lang/String;
    iget-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Ljava/lang/String;

    .restart local v12  # "initialDomain":Ljava/lang/String;
    iget-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    iget-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    .end local p1  # "url":Ljava/lang/String;
    .restart local v2  # "url":Ljava/lang/String;
    :try_start_9e
    invoke-static {v6}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_a1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_9e .. :try_end_a1} :catch_a7
    .catch Ljava/lang/Exception; {:try_start_9e .. :try_end_a1} :catch_a4

    move-object v0, v6

    goto/16 :goto_118

    .line 62
    :catch_a4
    move-exception v0

    goto/16 :goto_12c

    .line 60
    :catch_a7
    move-exception v0

    goto/16 :goto_1ed

    .line 48
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .end local v8  # "siteRequest":Z
    .end local v9  # "failure":Ljava/lang/Exception;
    .end local v10  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .end local v11  # "initialUrl":Ljava/lang/String;
    .end local v12  # "initialDomain":Ljava/lang/String;
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :pswitch_aa  #0x1
    iget-boolean v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    .restart local v0  # "siteRequest":Z
    iget-object v7, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    .local v7, "initialDomain":Ljava/lang/String;
    iget-object v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    move-object v3, v8

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    iget-object v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    move-object v2, v8

    check-cast v2, Ljava/lang/String;

    .end local p1  # "url":Ljava/lang/String;
    .restart local v2  # "url":Ljava/lang/String;
    invoke-static {v6}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v12, v7

    move-object v7, v6

    goto :goto_f2

    .end local v0  # "siteRequest":Z
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .end local v7  # "initialDomain":Ljava/lang/String;
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :pswitch_c0  #0x0
    invoke-static {v6}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 49
    iget-object v0, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/lang/String;

    .line 50
    .restart local v12  # "initialDomain":Ljava/lang/String;
    invoke-direct {v1, v2, v12}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->belongsToSite(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v8

    .line 51
    .restart local v8  # "siteRequest":Z
    if-nez v8, :cond_f3

    invoke-static/range {p1 .. p1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    invoke-static/range {p2 .. p2}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    invoke-static {v12}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    iput-boolean v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    const/4 v0, 0x1

    iput v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    invoke-interface {v3, v2, v5}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v7, :cond_f0

    .line 48
    return-object v7

    .line 51
    :cond_f0
    move-object v7, v0

    move v0, v8

    .line 52
    .end local v8  # "siteRequest":Z
    .end local p1  # "url":Ljava/lang/String;
    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local v0  # "siteRequest":Z
    .restart local v2  # "url":Ljava/lang/String;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    :goto_f2
    return-object v7

    .end local v0  # "siteRequest":Z
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local v8  # "siteRequest":Z
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :cond_f3
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    iget-object v9, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    iget-object v10, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v0, v2, v9, v12, v10}, Lapp/manitux/cloudstream/shared/RemoteConfig;->rebaseSiteUrl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 53
    .restart local v11  # "initialUrl":Ljava/lang/String;
    const/4 v10, 0x0

    .line 54
    .restart local v10  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    const/4 v9, 0x0

    .line 55
    .restart local v9  # "failure":Ljava/lang/Exception;
    nop

    .line 56
    :try_start_100
    invoke-static/range {p1 .. p1}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    iput-object v3, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    iput-object v12, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    iput-object v11, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$3:Ljava/lang/Object;

    iput-boolean v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    const/4 v0, 0x2

    iput v0, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    invoke-interface {v3, v11, v5}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_115
    .catch Ljava/util/concurrent/CancellationException; {:try_start_100 .. :try_end_115} :catch_1ec
    .catch Ljava/lang/Exception; {:try_start_100 .. :try_end_115} :catch_12b

    if-ne v0, v7, :cond_118

    .line 48
    return-object v7

    .end local p1  # "url":Ljava/lang/String;
    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local v2  # "url":Ljava/lang/String;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    :cond_118
    :goto_118
    :try_start_118
    check-cast v0, Lcom/lagradost/nicehttp/NiceResponse;

    move-object v10, v0

    .line 58
    invoke-virtual {v10}, Lcom/lagradost/nicehttp/NiceResponse;->getText()Ljava/lang/String;

    .line 59
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainFailurePolicy;

    invoke-virtual {v10}, Lcom/lagradost/nicehttp/NiceResponse;->getCode()I

    move-result v13

    invoke-virtual {v0, v13}, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->isDomainFailureStatus$FilmMakinesi_debug(I)Z

    move-result v0
    :try_end_128
    .catch Ljava/util/concurrent/CancellationException; {:try_start_118 .. :try_end_128} :catch_a7
    .catch Ljava/lang/Exception; {:try_start_118 .. :try_end_128} :catch_a4

    if-nez v0, :cond_138

    return-object v10

    .line 62
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :catch_12b
    move-exception v0

    .line 63
    .end local p1  # "url":Ljava/lang/String;
    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .local v0, "error":Ljava/lang/Exception;
    .restart local v2  # "url":Ljava/lang/String;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    :goto_12c
    sget-object v13, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainFailurePolicy;

    move-object v14, v0

    check-cast v14, Ljava/lang/Throwable;

    invoke-virtual {v13, v14}, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->isDomainFailure$FilmMakinesi_debug(Ljava/lang/Throwable;)Z

    move-result v13

    if-eqz v13, :cond_1eb

    .line 64
    move-object v9, v0

    .line 66
    .end local v0  # "error":Ljava/lang/Exception;
    :cond_138
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    iget-object v13, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    iget-object v14, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    invoke-static {v2}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    iput-object v15, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    iput-object v3, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    iput-object v12, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    iput-object v11, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$3:Ljava/lang/Object;

    iput-object v10, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$4:Ljava/lang/Object;

    iput-object v9, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$5:Ljava/lang/Object;

    iput-boolean v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    const/4 v15, 0x3

    iput v15, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    invoke-virtual {v0, v13, v14, v5}, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshAfterFailure(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v7, :cond_15a

    .line 48
    return-object v7

    :cond_15a
    :goto_15a
    check-cast v0, Ljava/lang/String;

    .line 68
    .local v0, "updated":Ljava/lang/String;
    sget-object v13, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    iget-object v14, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v13, v14, v12}, Lapp/manitux/cloudstream/shared/DomainSettings;->rememberDomain(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    sget-object v13, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    iget-object v14, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v13, v11, v12, v0, v14}, Lapp/manitux/cloudstream/shared/RemoteConfig;->rebaseSiteUrl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 70
    .local v13, "retryUrl":Ljava/lang/String;
    sget-object v14, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainFailurePolicy;

    invoke-virtual {v14, v11, v13}, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->sameOrigin$FilmMakinesi_debug(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_1d9

    .line 71
    iget-object v14, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->applyDomain:Lkotlin/jvm/functions/Function1;

    invoke-interface {v14, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v15, v1, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    const-string v15, " alan adı hatası; güncel adresle yeniden deneniyor: "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const-string v15, "Manitux_Domains"

    invoke-static {v15, v14}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 73
    invoke-static {v2}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$0:Ljava/lang/Object;

    invoke-static {v3}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$1:Ljava/lang/Object;

    invoke-static {v12}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$2:Ljava/lang/Object;

    invoke-static {v11}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$3:Ljava/lang/Object;

    invoke-static {v10}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$4:Ljava/lang/Object;

    invoke-static {v9}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$5:Ljava/lang/Object;

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$6:Ljava/lang/Object;

    invoke-static {v13}, Lkotlin/coroutines/jvm/internal/SpillingKt;->nullOutSpilledVariable(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    iput-object v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->L$7:Ljava/lang/Object;

    iput-boolean v8, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->Z$0:Z

    const/4 v14, 0x4

    iput v14, v5, Lapp/manitux/cloudstream/shared/DomainHttpClient$request$1;->label:I

    invoke-interface {v3, v13, v5}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v7, :cond_1d2

    .line 48
    return-object v7

    .line 73
    :cond_1d2
    move-object v7, v13

    move/from16 v16, v8

    move-object v8, v0

    move/from16 v0, v16

    .line 75
    .end local v13  # "retryUrl":Ljava/lang/String;
    .local v0, "siteRequest":Z
    .local v7, "retryUrl":Ljava/lang/String;
    .local v8, "updated":Ljava/lang/String;
    :goto_1d8
    return-object v14

    .end local v7  # "retryUrl":Ljava/lang/String;
    .local v0, "updated":Ljava/lang/String;
    .local v8, "siteRequest":Z
    .restart local v13  # "retryUrl":Ljava/lang/String;
    :cond_1d9
    if-nez v9, :cond_1ea

    .line 76
    if-eqz v10, :cond_1de

    return-object v10

    :cond_1de
    new-instance v7, Ljava/lang/IllegalStateException;

    const-string v14, "Required value was null."

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-direct {v7, v14}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v7

    .line 75
    :cond_1ea
    throw v9

    .line 63
    .end local v13  # "retryUrl":Ljava/lang/String;
    .local v0, "error":Ljava/lang/Exception;
    :cond_1eb
    throw v0

    .line 60
    .end local v0  # "error":Ljava/lang/Exception;
    .end local v2  # "url":Ljava/lang/String;
    .end local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    .restart local p1  # "url":Ljava/lang/String;
    .restart local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    :catch_1ec
    move-exception v0

    .line 61
    .end local p1  # "url":Ljava/lang/String;
    .end local p2  # "fetch":Lkotlin/jvm/functions/Function2;
    .local v0, "error":Ljava/util/concurrent/CancellationException;
    .restart local v2  # "url":Ljava/lang/String;
    .restart local v3  # "fetch":Lkotlin/jvm/functions/Function2;
    :goto_1ed
    throw v0

    :pswitch_data_1ee
    .packed-switch 0x0
        :pswitch_c0  #00000000
        :pswitch_aa  #00000001
        :pswitch_86  #00000002
        :pswitch_5f  #00000003
        :pswitch_35  #00000004
    .end packed-switch
.end method

.method private final requestHeaders(Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;
    .registers 24
    .param p1, "headers"  # Ljava/util/Map;
    .param p2, "original"  # Ljava/lang/String;
    .param p3, "target"  # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 89
    move-object/from16 v0, p0

    move-object/from16 v1, p3

    iget-object v2, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-direct {v0, v1, v2}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->belongsToSite(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_13

    return-object p1

    .line 90
    :cond_13
    new-instance v2, Ljava/net/URI;

    invoke-direct {v2, v1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 103
    .local v2, "it":Ljava/net/URI;
    const/4 v3, 0x0

    .line 90
    .local v3, "$i$a$-let-DomainHttpClient$requestHeaders$origin$1":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "://"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v2}, Ljava/net/URI;->getRawAuthority()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 91
    .end local v3  # "$i$a$-let-DomainHttpClient$requestHeaders$origin$1":I
    .local v2, "origin":Ljava/lang/String;
    move-object/from16 v3, p1

    .local v3, "$this$filterKeys$iv":Ljava/util/Map;
    const/4 v4, 0x0

    .line 104
    .local v4, "$i$f$filterKeys":I
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    .line 105
    .local v5, "result$iv":Ljava/util/LinkedHashMap;
    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_48
    :goto_48
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_96

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    .line 106
    .local v7, "entry$iv":Ljava/util/Map$Entry;
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .local v9, "it":Ljava/lang/String;
    const/4 v10, 0x0

    .line 91
    .local v10, "$i$a$-filterKeys-DomainHttpClient$requestHeaders$1":I
    sget-object v11, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainFailurePolicy;

    move-object/from16 v12, p2

    invoke-virtual {v11, v12, v1}, Lapp/manitux/cloudstream/shared/DomainFailurePolicy;->sameOrigin$FilmMakinesi_debug(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v11

    if-nez v11, :cond_87

    const-string v11, "authorization"

    const-string v13, "host"

    const-string v14, "cookie"

    filled-new-array {v14, v11, v13}, [Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v11

    sget-object v13, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v13}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "toLowerCase(...)"

    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v11, v13}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_85

    goto :goto_87

    :cond_85
    const/4 v8, 0x0

    goto :goto_88

    :cond_87
    :goto_87
    const/4 v8, 0x1

    .line 106
    .end local v9  # "it":Ljava/lang/String;
    .end local v10  # "$i$a$-filterKeys-DomainHttpClient$requestHeaders$1":I
    :goto_88
    if-eqz v8, :cond_48

    .line 107
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v5, v8, v9}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_48

    .line 110
    .end local v7  # "entry$iv":Ljava/util/Map$Entry;
    :cond_96
    move-object/from16 v12, p2

    move-object v3, v5

    check-cast v3, Ljava/util/Map;

    .line 92
    .end local v3  # "$this$filterKeys$iv":Ljava/util/Map;
    .end local v4  # "$i$f$filterKeys":I
    .end local v5  # "result$iv":Ljava/util/LinkedHashMap;
    nop

    .local v3, "$this$mapValues$iv":Ljava/util/Map;
    const/4 v4, 0x0

    .line 111
    .local v4, "$i$f$mapValues":I
    new-instance v5, Ljava/util/LinkedHashMap;

    invoke-interface {v3}, Ljava/util/Map;->size()I

    move-result v6

    invoke-static {v6}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v5, Ljava/util/Map;

    .local v5, "destination$iv$iv":Ljava/util/Map;
    move-object v6, v3

    .local v6, "$this$mapValuesTo$iv$iv":Ljava/util/Map;
    const/4 v7, 0x0

    .line 112
    .local v7, "$i$f$mapValuesTo":I
    invoke-interface {v6}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$associateByTo$iv$iv$iv":Ljava/lang/Iterable;
    move-object v10, v5

    .local v10, "destination$iv$iv$iv":Ljava/util/Map;
    const/4 v11, 0x0

    .line 113
    .local v11, "$i$f$associateByTo":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_ba
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_115

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .line 114
    .local v14, "element$iv$iv$iv":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/util/Map$Entry;

    .local v15, "it$iv$iv":Ljava/util/Map$Entry;
    const/16 v16, 0x0

    .line 112
    .local v16, "$i$a$-associateByTo-MapsKt__MapsKt$mapValuesTo$1$iv$iv":I
    invoke-interface {v15}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v15

    .line 114
    .end local v15  # "it$iv$iv":Ljava/util/Map$Entry;
    .end local v16  # "$i$a$-associateByTo-MapsKt__MapsKt$mapValuesTo$1$iv$iv":I
    move-object/from16 v16, v14

    check-cast v16, Ljava/util/Map$Entry;

    const/16 v17, 0x0

    .local v17, "$i$a$-mapValues-DomainHttpClient$requestHeaders$2":I
    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v8, v18

    check-cast v8, Ljava/lang/String;

    .local v8, "name":Ljava/lang/String;
    invoke-interface/range {v16 .. v16}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v1, v16

    check-cast v1, Ljava/lang/String;

    .line 93
    .local v1, "value":Ljava/lang/String;
    move-object/from16 v16, v3

    .end local v3  # "$this$mapValues$iv":Ljava/util/Map;
    .local v16, "$this$mapValues$iv":Ljava/util/Map;
    const-string v3, "Referer"

    move/from16 v18, v4

    const/4 v4, 0x1

    .end local v4  # "$i$f$mapValues":I
    .local v18, "$i$f$mapValues":I
    invoke-static {v8, v3, v4}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_fc

    const-string v3, "Origin"

    invoke-static {v8, v3, v4}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_f9

    goto :goto_fc

    .line 94
    :cond_f9
    move-object/from16 v19, v5

    goto :goto_109

    :cond_fc
    :goto_fc
    sget-object v3, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    iget-object v4, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    move-object/from16 v19, v5

    .end local v5  # "destination$iv$iv":Ljava/util/Map;
    .local v19, "destination$iv$iv":Ljava/util/Map;
    iget-object v5, v0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v3, v1, v4, v2, v5}, Lapp/manitux/cloudstream/shared/RemoteConfig;->rebaseSiteUrl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object v1, v3

    .line 114
    .end local v1  # "value":Ljava/lang/String;
    .end local v8  # "name":Ljava/lang/String;
    .end local v17  # "$i$a$-mapValues-DomainHttpClient$requestHeaders$2":I
    :goto_109
    invoke-interface {v10, v15, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, p3

    move-object/from16 v3, v16

    move/from16 v4, v18

    move-object/from16 v5, v19

    goto :goto_ba

    .line 116
    .end local v14  # "element$iv$iv$iv":Ljava/lang/Object;
    .end local v16  # "$this$mapValues$iv":Ljava/util/Map;
    .end local v18  # "$i$f$mapValues":I
    .end local v19  # "destination$iv$iv":Ljava/util/Map;
    .restart local v3  # "$this$mapValues$iv":Ljava/util/Map;
    .restart local v4  # "$i$f$mapValues":I
    .restart local v5  # "destination$iv$iv":Ljava/util/Map;
    :cond_115
    nop

    .line 112
    .end local v9  # "$this$associateByTo$iv$iv$iv":Ljava/lang/Iterable;
    .end local v10  # "destination$iv$iv$iv":Ljava/util/Map;
    .end local v11  # "$i$f$associateByTo":I
    nop

    .line 111
    .end local v5  # "destination$iv$iv":Ljava/util/Map;
    .end local v6  # "$this$mapValuesTo$iv$iv":Ljava/util/Map;
    .end local v7  # "$i$f$mapValuesTo":I
    nop

    .line 91
    .end local v3  # "$this$mapValues$iv":Ljava/util/Map;
    .end local v4  # "$i$f$mapValues":I
    return-object v10
.end method


# virtual methods
.method public final get(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 16
    .param p1, "url"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "headers"  # Ljava/util/Map;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "referer"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p4, "params"  # Ljava/util/Map;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p5, "cookies"  # Ljava/util/Map;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p6, "$completion"  # Lkotlin/coroutines/Continuation;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/lagradost/nicehttp/NiceResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 26
    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-direct {p0, p1, v0}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->belongsToSite(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    move-object v4, v0

    goto :goto_19

    :cond_18
    move-object v4, p1

    .line 27
    .local v4, "headerOrigin":Ljava/lang/String;
    :goto_19
    new-instance v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;

    const/4 v8, 0x0

    move-object v1, v0

    move-object v2, p0

    move-object v3, p2

    move-object v5, p3

    move-object v6, p4

    move-object v7, p5

    invoke-direct/range {v1 .. v8}, Lapp/manitux/cloudstream/shared/DomainHttpClient$get$2;-><init>(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-direct {p0, p1, v0, p6}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->request(Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final post(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 14
    .param p1, "url"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "headers"  # Ljava/util/Map;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "referer"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/Nullable;
        .end annotation
    .end param
    .param p4, "data"  # Ljava/util/Map;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p5, "$completion"  # Lkotlin/coroutines/Continuation;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/lagradost/nicehttp/NiceResponse;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    .line 41
    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-direct {p0, p1, v0}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->belongsToSite(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    iget-object v0, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    move-object v4, v0

    goto :goto_19

    :cond_18
    move-object v4, p1

    .line 42
    .local v4, "headerOrigin":Ljava/lang/String;
    :goto_19
    new-instance v0, Lapp/manitux/cloudstream/shared/DomainHttpClient$post$2;

    const/4 v7, 0x0

    move-object v1, v0

    move-object v2, p0

    move-object v3, p2

    move-object v5, p3

    move-object v6, p4

    invoke-direct/range {v1 .. v7}, Lapp/manitux/cloudstream/shared/DomainHttpClient$post$2;-><init>(Lapp/manitux/cloudstream/shared/DomainHttpClient;Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-direct {p0, p1, v0, p5}, Lapp/manitux/cloudstream/shared/DomainHttpClient;->request(Ljava/lang/String;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final siteUrl(Ljava/lang/String;)Ljava/lang/String;
    .registers 6
    .param p1, "url"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 17
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    iget-object v1, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->fallback:Ljava/lang/String;

    iget-object v2, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->currentDomain:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p0, Lapp/manitux/cloudstream/shared/DomainHttpClient;->key:Ljava/lang/String;

    invoke-virtual {v0, p1, v1, v2, v3}, Lapp/manitux/cloudstream/shared/RemoteConfig;->rebaseSiteUrl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
