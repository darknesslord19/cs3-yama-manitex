.class public final Lapp/manitux/cloudstream/shared/RemoteConfig;
.super Ljava/lang/Object;
.source "RemoteConfig.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nRemoteConfig.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RemoteConfig.kt\napp/manitux/cloudstream/shared/RemoteConfig\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Mutex.kt\nkotlinx/coroutines/sync/MutexKt\n*L\n1#1,101:1\n1#2:102\n1807#3,3:103\n116#4,10:106\n*S KotlinDebug\n*F\n+ 1 RemoteConfig.kt\napp/manitux/cloudstream/shared/RemoteConfig\n*L\n50#1:103,3\n59#1:106,10\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0005H\u0086@¢\u0006\u0002\u0010\u0014J\u001e\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0005H\u0086@¢\u0006\u0002\u0010\u0014J\u0016\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0005J&\u0010\u0017\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u0005J\u0018\u0010\u001a\u001a\u00020\u001b2\b\b\u0002\u0010\u001c\u001a\u00020\u001dH\u0082@¢\u0006\u0002\u0010\u001eJ!\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\f2\u0006\u0010 \u001a\u00020\u0005H\u0000¢\u0006\u0002\b!J\u000e\u0010\"\u001a\u00020\u001d2\u0006\u0010#\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006$"
    }
    d2 = {
        "Lapp/manitux/cloudstream/shared/RemoteConfig;",
        "",
        "<init>",
        "()V",
        "DOMAINS_URL",
        "",
        "RETRY_AFTER_MS",
        "",
        "REFRESH_AFTER_MS",
        "FAILURE_REFRESH_AFTER_MS",
        "TAG",
        "domains",
        "",
        "nextRefresh",
        "nextFailureRefresh",
        "refreshMutex",
        "Lkotlinx/coroutines/sync/Mutex;",
        "getDomain",
        "key",
        "fallback",
        "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "refreshAfterFailure",
        "cachedDomain",
        "rebaseSiteUrl",
        "url",
        "current",
        "refreshIfNeeded",
        "",
        "force",
        "",
        "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;",
        "parseDomains",
        "text",
        "parseDomains$FilmMakinesi_debug",
        "isSafeBaseUrl",
        "value",
        "FilmMakinesi_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x3,
        0x0
    }
    xi = 0x30
.end annotation

.annotation build Lkotlin/jvm/internal/SourceDebugExtension;
    value = {
        "SMAP\nRemoteConfig.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RemoteConfig.kt\napp/manitux/cloudstream/shared/RemoteConfig\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Mutex.kt\nkotlinx/coroutines/sync/MutexKt\n*L\n1#1,101:1\n1#2:102\n1807#3,3:103\n116#4,10:106\n*S KotlinDebug\n*F\n+ 1 RemoteConfig.kt\napp/manitux/cloudstream/shared/RemoteConfig\n*L\n50#1:103,3\n59#1:106,10\n*E\n"
    }
.end annotation


# static fields
.field public static final DOMAINS_URL:Ljava/lang/String; = "https://raw.githubusercontent.com/darknesslord19/cloudstream_tr/main/domains.json"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final FAILURE_REFRESH_AFTER_MS:J = 0xea60L

.field public static final INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static final REFRESH_AFTER_MS:J = 0x1b7740L

.field private static final RETRY_AFTER_MS:J = 0x493e0L

.field private static final TAG:Ljava/lang/String; = "Manitux_Domains"
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static volatile domains:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field

.field private static nextFailureRefresh:J

.field private static volatile nextRefresh:J

.field private static final refreshMutex:Lkotlinx/coroutines/sync/Mutex;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$HRJGdiRLBxFHi1J3SHnnFknjA7w(Lapp/manitux/cloudstream/shared/RemoteConfig;Ljava/util/Map$Entry;)Lkotlin/Pair;
    .registers 2

    invoke-static {p0, p1}, Lapp/manitux/cloudstream/shared/RemoteConfig;->parseDomains$lambda$0$0(Lapp/manitux/cloudstream/shared/RemoteConfig;Ljava/util/Map$Entry;)Lkotlin/Pair;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-direct {v0}, Lapp/manitux/cloudstream/shared/RemoteConfig;-><init>()V

    sput-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    .line 19
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v0

    sput-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->domains:Ljava/util/Map;

    .line 22
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v2, v0, v1}, Lkotlinx/coroutines/sync/MutexKt;->Mutex$default(ZILjava/lang/Object;)Lkotlinx/coroutines/sync/Mutex;

    move-result-object v0

    sput-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshMutex:Lkotlinx/coroutines/sync/Mutex;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$refreshIfNeeded(Lapp/manitux/cloudstream/shared/RemoteConfig;ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 4
    .param p0, "$this"  # Lapp/manitux/cloudstream/shared/RemoteConfig;
    .param p1, "force"  # Z
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;

    .line 12
    invoke-direct {p0, p1, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshIfNeeded(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method private static final parseDomains$lambda$0$0(Lapp/manitux/cloudstream/shared/RemoteConfig;Ljava/util/Map$Entry;)Lkotlin/Pair;
    .registers 8
    .param p0, "$this_runCatching"  # Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .local v0, "key":Ljava/lang/String;
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/fasterxml/jackson/databind/JsonNode;

    .line 89
    .local p1, "value":Lcom/fasterxml/jackson/databind/JsonNode;
    invoke-virtual {p1}, Lcom/fasterxml/jackson/databind/JsonNode;->isTextual()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_14

    return-object v2

    .line 90
    :cond_14
    invoke-virtual {p1}, Lcom/fasterxml/jackson/databind/JsonNode;->asText()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    new-array v3, v3, [C

    const/16 v4, 0x2f

    const/4 v5, 0x0

    aput-char v4, v3, v5

    invoke-static {v1, v3}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v1

    .line 91
    .local v1, "domain":Ljava/lang/String;
    invoke-virtual {p0, v1}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_43

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "toLowerCase(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    .end local v1  # "domain":Ljava/lang/String;
    :cond_43
    return-object v2
.end method

.method private final refreshIfNeeded(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 35
    .param p1, "force"  # Z
    .param p2, "$completion"  # Lkotlin/coroutines/Continuation;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    move-object/from16 v1, p2

    instance-of v0, v1, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;

    if-eqz v0, :cond_18

    move-object v0, v1

    check-cast v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;

    iget v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    const/high16 v3, -0x80000000

    and-int/2addr v2, v3

    if-eqz v2, :cond_18

    iget v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    sub-int/2addr v2, v3

    iput v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    move-object/from16 v2, p0

    goto :goto_1f

    :cond_18
    new-instance v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;

    move-object/from16 v2, p0

    invoke-direct {v0, v2, v1}, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;-><init>(Lapp/manitux/cloudstream/shared/RemoteConfig;Lkotlin/coroutines/Continuation;)V

    :goto_1f
    move-object v4, v0

    .local v4, "$continuation":Lkotlin/coroutines/Continuation;
    iget-object v3, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->result:Ljava/lang/Object;

    .local v3, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 59
    iget v5, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    const/4 v15, 0x1

    const-string v14, "Manitux_Domains"

    packed-switch v5, :pswitch_data_258

    move-object/from16 v30, v3

    .end local v3  # "$result":Ljava/lang/Object;
    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local v3  # "$result":Ljava/lang/Object;
    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    :pswitch_38  #0x2
    iget-wide v5, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->J$0:J

    .local v5, "now":J
    iget v7, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->I$1:I

    .local v7, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    iget v8, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->I$0:I

    .local v8, "$i$f$withLock":I
    iget-boolean v9, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->Z$0:Z

    .end local p1  # "force":Z
    .local v9, "force":Z
    const/4 v10, 0x0

    .local v10, "owner$iv":Ljava/lang/Object;
    iget-object v0, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->L$0:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Lkotlinx/coroutines/sync/Mutex;

    .local v11, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    :try_start_46
    invoke-static {v3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_49
    .catch Ljava/util/concurrent/CancellationException; {:try_start_46 .. :try_end_49} :catch_62
    .catch Ljava/lang/Exception; {:try_start_46 .. :try_end_49} :catch_5a
    .catchall {:try_start_46 .. :try_end_49} :catchall_53

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-object/from16 v28, v14

    const/16 v29, 0x1

    goto/16 :goto_130

    .line 114
    .end local v5  # "now":J
    .end local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    :catchall_53
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    goto/16 :goto_254

    .line 80
    .restart local v5  # "now":J
    .restart local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    :catch_5a
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-object v12, v14

    goto/16 :goto_1f8

    .line 76
    :catch_62
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    goto/16 :goto_21a

    .line 59
    .end local v5  # "now":J
    .end local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .end local v8  # "$i$f$withLock":I
    .end local v9  # "force":Z
    .end local v10  # "owner$iv":Ljava/lang/Object;
    .end local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local p1  # "force":Z
    :pswitch_69  #0x1
    iget v5, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->I$0:I

    .local v5, "$i$f$withLock":I
    iget-boolean v6, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->Z$0:Z

    .end local p1  # "force":Z
    .local v6, "force":Z
    const/4 v7, 0x0

    .local v7, "owner$iv":Ljava/lang/Object;
    iget-object v8, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->L$0:Ljava/lang/Object;

    check-cast v8, Lkotlinx/coroutines/sync/Mutex;

    .local v8, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    invoke-static {v3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move v13, v5

    move v12, v6

    move-object/from16 v20, v7

    move-object v11, v8

    goto :goto_99

    .end local v5  # "$i$f$withLock":I
    .end local v6  # "force":Z
    .end local v7  # "owner$iv":Ljava/lang/Object;
    .end local v8  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local p1  # "force":Z
    :pswitch_7b  #0x0
    invoke-static {v3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    sget-object v5, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshMutex:Lkotlinx/coroutines/sync/Mutex;

    .line 106
    .local v5, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    const/4 v6, 0x0

    .local v6, "owner$iv":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 107
    .local v7, "$i$f$withLock":I
    nop

    .line 110
    iput-object v5, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->L$0:Ljava/lang/Object;

    move/from16 v8, p1

    iput-boolean v8, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->Z$0:Z

    iput v7, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->I$0:I

    iput v15, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I

    invoke-interface {v5, v6, v4}, Lkotlinx/coroutines/sync/Mutex;->lock(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v0, :cond_94

    .line 59
    return-object v0

    .line 110
    :cond_94
    move-object v11, v5

    move-object/from16 v20, v6

    move v13, v7

    move v12, v8

    .line 111
    .end local v5  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v6  # "owner$iv":Ljava/lang/Object;
    .end local v7  # "$i$f$withLock":I
    .end local p1  # "force":Z
    .restart local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .local v12, "force":Z
    .local v13, "$i$f$withLock":I
    .local v20, "owner$iv":Ljava/lang/Object;
    :goto_99
    nop

    .line 112
    const/4 v10, 0x0

    .line 60
    .local v10, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    :try_start_9b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5
    :try_end_9f
    .catchall {:try_start_9b .. :try_end_9f} :catchall_243

    move-wide v8, v5

    .line 61
    .local v8, "now":J
    if-eqz v12, :cond_bf

    .line 62
    :try_start_a2
    sget-wide v5, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextFailureRefresh:J
    :try_end_a4
    .catchall {:try_start_a2 .. :try_end_a4} :catchall_b4

    cmp-long v7, v8, v5

    if-gez v7, :cond_c5

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-object/from16 v25, v11

    move/from16 v26, v12

    move/from16 v27, v13

    goto/16 :goto_232

    .line 114
    .end local v8  # "now":J
    .end local v10  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    :catchall_b4
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move v9, v12

    move v8, v13

    move-object/from16 v10, v20

    goto/16 :goto_254

    .line 63
    .restart local v8  # "now":J
    .restart local v10  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    :cond_bf
    :try_start_bf
    sget-wide v5, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextRefresh:J

    cmp-long v7, v8, v5

    if-ltz v7, :cond_224

    .line 64
    :cond_c5
    const-wide/32 v5, 0xea60

    add-long/2addr v5, v8

    sput-wide v5, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextFailureRefresh:J

    .line 65
    const-wide/32 v5, 0x493e0

    add-long/2addr v5, v8

    sput-wide v5, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextRefresh:J
    :try_end_d1
    .catchall {:try_start_bf .. :try_end_d1} :catchall_243

    .line 66
    nop

    .line 67
    :try_start_d2
    invoke-static {}, Lcom/lagradost/cloudstream3/MainActivityKt;->getApp()Lcom/lagradost/nicehttp/Requests;

    move-result-object v17

    const-string v21, "https://raw.githubusercontent.com/darknesslord19/cloudstream_tr/main/domains.json"

    iput-object v11, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->L$0:Ljava/lang/Object;

    iput-boolean v12, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->Z$0:Z

    iput v13, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->I$0:I

    iput v10, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->I$1:I

    iput-wide v8, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->J$0:J

    const/4 v5, 0x2

    iput v5, v4, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshIfNeeded$1;->label:I
    :try_end_e5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_d2 .. :try_end_e5} :catch_201
    .catch Ljava/lang/Exception; {:try_start_d2 .. :try_end_e5} :catch_1de
    .catchall {:try_start_d2 .. :try_end_e5} :catchall_243

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/16 v16, 0x0

    move-wide/from16 v22, v8

    .end local v8  # "now":J
    .local v22, "now":J
    move-object/from16 v8, v16

    const/4 v9, 0x0

    const/16 v16, 0x0

    move/from16 v24, v10

    .end local v10  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .local v24, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    move/from16 v10, v16

    const/16 v16, 0x0

    move-object/from16 v25, v11

    .end local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .local v25, "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    move-object/from16 v11, v16

    const-wide/16 v18, 0x8

    move/from16 v26, v12

    move/from16 v27, v13

    .end local v12  # "force":Z
    .end local v13  # "$i$f$withLock":I
    .local v26, "force":Z
    .local v27, "$i$f$withLock":I
    move-wide/from16 v12, v18

    move-object/from16 v28, v14

    move-object/from16 v14, v16

    const/16 v16, 0x0

    const/16 v29, 0x1

    move/from16 v15, v16

    const/16 v16, 0x0

    const/16 v18, 0xefe

    const/16 v19, 0x0

    move-object/from16 v30, v3

    .end local v3  # "$result":Ljava/lang/Object;
    .local v30, "$result":Ljava/lang/Object;
    move-object/from16 v3, v17

    move-object/from16 v31, v4

    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v31, "$continuation":Lkotlin/coroutines/Continuation;
    move-object/from16 v4, v21

    move-object/from16 v17, v31

    :try_start_11d
    invoke-static/range {v3 .. v19}, Lcom/lagradost/nicehttp/Requests;->get$default(Lcom/lagradost/nicehttp/Requests;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;ZILjava/util/concurrent/TimeUnit;JLokhttp3/Interceptor;ZLcom/lagradost/nicehttp/ResponseParser;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_121
    .catch Ljava/util/concurrent/CancellationException; {:try_start_11d .. :try_end_121} :catch_1d0
    .catch Ljava/lang/Exception; {:try_start_11d .. :try_end_121} :catch_1c0
    .catchall {:try_start_11d .. :try_end_121} :catchall_1b5

    if-ne v3, v0, :cond_124

    .line 59
    return-object v0

    .line 67
    :cond_124
    move-object/from16 v10, v20

    move-wide/from16 v5, v22

    move/from16 v7, v24

    move-object/from16 v11, v25

    move/from16 v9, v26

    move/from16 v8, v27

    .line 59
    .end local v20  # "owner$iv":Ljava/lang/Object;
    .end local v22  # "now":J
    .end local v24  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .end local v25  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v26  # "force":Z
    .end local v27  # "$i$f$withLock":I
    .local v5, "now":J
    .local v7, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .local v8, "$i$f$withLock":I
    .restart local v9  # "force":Z
    .local v10, "owner$iv":Ljava/lang/Object;
    .restart local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    :goto_130
    :try_start_130
    check-cast v3, Lcom/lagradost/nicehttp/NiceResponse;

    move-object v0, v3

    .line 68
    .local v0, "response":Lcom/lagradost/nicehttp/NiceResponse;
    sget-object v3, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    invoke-virtual {v0}, Lcom/lagradost/nicehttp/NiceResponse;->getText()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lapp/manitux/cloudstream/shared/RemoteConfig;->parseDomains$FilmMakinesi_debug(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v3

    .line 69
    .local v3, "parsed":Ljava/util/Map;
    invoke-virtual {v0}, Lcom/lagradost/nicehttp/NiceResponse;->getCode()I

    move-result v4

    const/16 v12, 0xc8

    const/4 v15, 0x0

    if-gt v12, v4, :cond_14b

    const/16 v12, 0x12c

    if-ge v4, v12, :cond_14b

    const/4 v15, 0x1

    :cond_14b
    if-eqz v15, :cond_180

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_156

    move-object/from16 v12, v28

    goto :goto_182

    .line 73
    :cond_156
    sput-object v3, Lapp/manitux/cloudstream/shared/RemoteConfig;->domains:Ljava/util/Map;

    .line 74
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    const-wide/32 v14, 0x1b7740

    add-long/2addr v12, v14

    sput-wide v12, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextRefresh:J

    .line 75
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "domains.json yüklendi count="

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-interface {v3}, Ljava/util/Map;->size()I

    move-result v12

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4
    :try_end_179
    .catch Ljava/util/concurrent/CancellationException; {:try_start_130 .. :try_end_179} :catch_1b2
    .catch Ljava/lang/Exception; {:try_start_130 .. :try_end_179} :catch_1ae
    .catchall {:try_start_130 .. :try_end_179} :catchall_222

    move-object/from16 v12, v28

    :try_start_17b
    invoke-static {v12, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .end local v0  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .end local v3  # "parsed":Ljava/util/Map;
    goto/16 :goto_200

    .line 69
    .restart local v0  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .restart local v3  # "parsed":Ljava/util/Map;
    :cond_180
    move-object/from16 v12, v28

    .line 70
    :goto_182
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "domains.json geçersiz code="

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v0}, Lcom/lagradost/nicehttp/NiceResponse;->getCode()I

    move-result v13

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v13, " count="

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-interface {v3}, Ljava/util/Map;->size()I

    move-result v13

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v12, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1aa
    .catch Ljava/util/concurrent/CancellationException; {:try_start_17b .. :try_end_1aa} :catch_1b2
    .catch Ljava/lang/Exception; {:try_start_17b .. :try_end_1aa} :catch_1ac
    .catchall {:try_start_17b .. :try_end_1aa} :catchall_222

    .line 71
    goto/16 :goto_23a

    .line 80
    .end local v0  # "response":Lcom/lagradost/nicehttp/NiceResponse;
    .end local v3  # "parsed":Ljava/util/Map;
    :catch_1ac
    move-exception v0

    goto :goto_1f8

    :catch_1ae
    move-exception v0

    move-object/from16 v12, v28

    goto :goto_1f8

    .line 76
    :catch_1b2
    move-exception v0

    goto/16 :goto_21a

    .line 114
    .end local v5  # "now":J
    .end local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .end local v8  # "$i$f$withLock":I
    .end local v9  # "force":Z
    .end local v10  # "owner$iv":Ljava/lang/Object;
    .end local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v20  # "owner$iv":Ljava/lang/Object;
    .restart local v25  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v26  # "force":Z
    .restart local v27  # "$i$f$withLock":I
    :catchall_1b5
    move-exception v0

    move-object/from16 v10, v20

    move-object/from16 v11, v25

    move/from16 v9, v26

    move/from16 v8, v27

    goto/16 :goto_254

    .line 80
    .restart local v22  # "now":J
    .restart local v24  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    :catch_1c0
    move-exception v0

    move-object/from16 v12, v28

    move-object/from16 v10, v20

    move-wide/from16 v5, v22

    move/from16 v7, v24

    move-object/from16 v11, v25

    move/from16 v9, v26

    move/from16 v8, v27

    goto :goto_1f8

    .line 76
    :catch_1d0
    move-exception v0

    move-object/from16 v10, v20

    move-wide/from16 v5, v22

    move/from16 v7, v24

    move-object/from16 v11, v25

    move/from16 v9, v26

    move/from16 v8, v27

    goto :goto_21a

    .line 80
    .end local v22  # "now":J
    .end local v24  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .end local v25  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v26  # "force":Z
    .end local v27  # "$i$f$withLock":I
    .end local v30  # "$result":Ljava/lang/Object;
    .end local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v3, "$result":Ljava/lang/Object;
    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v8, "now":J
    .local v10, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .restart local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v12  # "force":Z
    .restart local v13  # "$i$f$withLock":I
    :catch_1de
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-wide/from16 v22, v8

    move/from16 v24, v10

    move-object/from16 v25, v11

    move/from16 v26, v12

    move/from16 v27, v13

    move-object v12, v14

    move-object/from16 v10, v20

    move-wide/from16 v5, v22

    move/from16 v7, v24

    move/from16 v9, v26

    move/from16 v8, v27

    .line 81
    .end local v3  # "$result":Ljava/lang/Object;
    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v12  # "force":Z
    .end local v13  # "$i$f$withLock":I
    .end local v20  # "owner$iv":Ljava/lang/Object;
    .local v0, "error":Ljava/lang/Exception;
    .restart local v5  # "now":J
    .restart local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .local v8, "$i$f$withLock":I
    .restart local v9  # "force":Z
    .local v10, "owner$iv":Ljava/lang/Object;
    .restart local v30  # "$result":Ljava/lang/Object;
    .restart local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_1f8
    :try_start_1f8
    const-string v3, "domains.json okunamadı; mevcut/yerleşik adresler kullanılacak"

    move-object v4, v0

    check-cast v4, Ljava/lang/Throwable;

    invoke-static {v12, v3, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 83
    .end local v0  # "error":Ljava/lang/Exception;
    :goto_200
    goto :goto_23a

    .line 76
    .end local v5  # "now":J
    .end local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .end local v9  # "force":Z
    .end local v30  # "$result":Ljava/lang/Object;
    .end local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v3  # "$result":Ljava/lang/Object;
    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v8, "now":J
    .local v10, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .restart local v12  # "force":Z
    .restart local v13  # "$i$f$withLock":I
    .restart local v20  # "owner$iv":Ljava/lang/Object;
    :catch_201
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-wide/from16 v22, v8

    move/from16 v24, v10

    move-object/from16 v25, v11

    move/from16 v26, v12

    move/from16 v27, v13

    move-object/from16 v10, v20

    move-wide/from16 v5, v22

    move/from16 v7, v24

    move/from16 v9, v26

    move/from16 v8, v27

    .line 77
    .end local v3  # "$result":Ljava/lang/Object;
    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v12  # "force":Z
    .end local v13  # "$i$f$withLock":I
    .end local v20  # "owner$iv":Ljava/lang/Object;
    .local v0, "error":Ljava/util/concurrent/CancellationException;
    .restart local v5  # "now":J
    .restart local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .local v8, "$i$f$withLock":I
    .restart local v9  # "force":Z
    .local v10, "owner$iv":Ljava/lang/Object;
    .restart local v30  # "$result":Ljava/lang/Object;
    .restart local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_21a
    const-wide/16 v3, 0x0

    sput-wide v3, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextRefresh:J

    .line 78
    sput-wide v3, Lapp/manitux/cloudstream/shared/RemoteConfig;->nextFailureRefresh:J

    .line 79
    nop

    .end local v8  # "$i$f$withLock":I
    .end local v9  # "force":Z
    .end local v10  # "owner$iv":Ljava/lang/Object;
    .end local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v30  # "$result":Ljava/lang/Object;
    .end local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local p2  # "$completion":Lkotlin/coroutines/Continuation;
    throw v0

    .line 114
    .end local v0  # "error":Ljava/util/concurrent/CancellationException;
    .end local v5  # "now":J
    .end local v7  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .restart local v8  # "$i$f$withLock":I
    .restart local v9  # "force":Z
    .restart local v10  # "owner$iv":Ljava/lang/Object;
    .restart local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v30  # "$result":Ljava/lang/Object;
    .restart local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local p2  # "$completion":Lkotlin/coroutines/Continuation;
    :catchall_222
    move-exception v0

    goto :goto_254

    .line 63
    .end local v9  # "force":Z
    .end local v30  # "$result":Ljava/lang/Object;
    .end local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v3  # "$result":Ljava/lang/Object;
    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .local v8, "now":J
    .local v10, "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .restart local v12  # "force":Z
    .restart local v13  # "$i$f$withLock":I
    .restart local v20  # "owner$iv":Ljava/lang/Object;
    :cond_224
    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-wide/from16 v22, v8

    move/from16 v24, v10

    move-object/from16 v25, v11

    move/from16 v26, v12

    move/from16 v27, v13

    .line 83
    .end local v3  # "$result":Ljava/lang/Object;
    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v8  # "now":J
    .end local v10  # "$i$a$-withLock$default-RemoteConfig$refreshIfNeeded$2":I
    .end local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v12  # "force":Z
    .end local v13  # "$i$f$withLock":I
    .restart local v25  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v26  # "force":Z
    .restart local v27  # "$i$f$withLock":I
    .restart local v30  # "$result":Ljava/lang/Object;
    .restart local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_232
    move-object/from16 v10, v20

    move-object/from16 v11, v25

    move/from16 v9, v26

    move/from16 v8, v27

    .end local v20  # "owner$iv":Ljava/lang/Object;
    .end local v25  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .end local v26  # "force":Z
    .end local v27  # "$i$f$withLock":I
    .local v8, "$i$f$withLock":I
    .restart local v9  # "force":Z
    .local v10, "owner$iv":Ljava/lang/Object;
    .restart local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    :goto_23a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_23c
    .catchall {:try_start_1f8 .. :try_end_23c} :catchall_222

    .line 112
    nop

    .line 114
    invoke-interface {v11, v10}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    .line 115
    nop

    .line 111
    nop

    .line 83
    .end local v8  # "$i$f$withLock":I
    .end local v10  # "owner$iv":Ljava/lang/Object;
    .end local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    return-object v0

    .line 114
    .end local v9  # "force":Z
    .end local v30  # "$result":Ljava/lang/Object;
    .end local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v3  # "$result":Ljava/lang/Object;
    .restart local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v11  # "$this$withLock_u24default$iv":Lkotlinx/coroutines/sync/Mutex;
    .restart local v12  # "force":Z
    .restart local v13  # "$i$f$withLock":I
    .restart local v20  # "owner$iv":Ljava/lang/Object;
    :catchall_243
    move-exception v0

    move-object/from16 v30, v3

    move-object/from16 v31, v4

    move-object/from16 v25, v11

    move/from16 v26, v12

    move/from16 v27, v13

    move-object/from16 v10, v20

    move/from16 v9, v26

    move/from16 v8, v27

    .end local v3  # "$result":Ljava/lang/Object;
    .end local v4  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v12  # "force":Z
    .end local v13  # "$i$f$withLock":I
    .end local v20  # "owner$iv":Ljava/lang/Object;
    .restart local v8  # "$i$f$withLock":I
    .restart local v9  # "force":Z
    .restart local v10  # "owner$iv":Ljava/lang/Object;
    .restart local v30  # "$result":Ljava/lang/Object;
    .restart local v31  # "$continuation":Lkotlin/coroutines/Continuation;
    :goto_254
    invoke-interface {v11, v10}, Lkotlinx/coroutines/sync/Mutex;->unlock(Ljava/lang/Object;)V

    throw v0

    :pswitch_data_258
    .packed-switch 0x0
        :pswitch_7b  #00000000
        :pswitch_69  #00000001
        :pswitch_38  #00000002
    .end packed-switch
.end method

.method static synthetic refreshIfNeeded$default(Lapp/manitux/cloudstream/shared/RemoteConfig;ZLkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 59
    and-int/lit8 p3, p3, 0x1

    if-eqz p3, :cond_5

    const/4 p1, 0x0

    :cond_5
    invoke-direct {p0, p1, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshIfNeeded(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final cachedDomain(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 7
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 37
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v0, p1}, Lapp/manitux/cloudstream/shared/DomainSettings;->getOverride(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_38

    .line 38
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->domains:Ljava/util/Map;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "toLowerCase(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const/4 v1, 0x0

    if-eqz v0, :cond_29

    move-object v2, v0

    .line 102
    .local v2, "p0":Ljava/lang/String;
    const/4 v3, 0x0

    .line 38
    .local v3, "$i$a$-takeIf-RemoteConfig$cachedDomain$selected$1":I
    invoke-virtual {p0, v2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v2

    .end local v2  # "p0":Ljava/lang/String;
    .end local v3  # "$i$a$-takeIf-RemoteConfig$cachedDomain$selected$1":I
    if-eqz v2, :cond_27

    goto :goto_2a

    :cond_27
    move-object v0, v1

    goto :goto_2a

    :cond_29
    move-object v0, v1

    .line 37
    :goto_2a
    if-nez v0, :cond_38

    .line 39
    const/4 v0, 0x1

    new-array v0, v0, [C

    const/16 v1, 0x2f

    const/4 v2, 0x0

    aput-char v1, v0, v2

    invoke-static {p2, v0}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v0

    .line 37
    :cond_38
    nop

    .line 40
    .local v0, "selected":Ljava/lang/String;
    sget-object v1, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v1, p1, p2}, Lapp/manitux/cloudstream/shared/DomainSettings;->rememberDomain(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    sget-object v1, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v1, p1, v0}, Lapp/manitux/cloudstream/shared/DomainSettings;->rememberDomain(Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    return-object v0
.end method

.method public final getDomain(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 10
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "$completion"  # Lkotlin/coroutines/Continuation;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    instance-of v0, p3, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;

    if-eqz v0, :cond_14

    move-object v0, p3

    check-cast v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;

    iget v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_14

    iget v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->label:I

    sub-int/2addr v1, v2

    iput v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->label:I

    goto :goto_19

    :cond_14
    new-instance v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;

    invoke-direct {v0, p0, p3}, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;-><init>(Lapp/manitux/cloudstream/shared/RemoteConfig;Lkotlin/coroutines/Continuation;)V

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_19
    iget-object v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->result:Ljava/lang/Object;

    .local v1, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v2

    .line 24
    iget v3, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->label:I

    packed-switch v3, :pswitch_data_60

    .end local v0  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v1  # "$result":Ljava/lang/Object;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local v0  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v1  # "$result":Ljava/lang/Object;
    :pswitch_2c  #0x1
    iget-object v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->L$1:Ljava/lang/Object;

    move-object p2, v2

    check-cast p2, Ljava/lang/String;

    iget-object v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->L$0:Ljava/lang/Object;

    move-object p1, v2

    check-cast p1, Ljava/lang/String;

    invoke-static {v1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_5a

    :pswitch_3a  #0x0
    invoke-static {v1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 25
    sget-object v3, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    invoke-virtual {v3, p1}, Lapp/manitux/cloudstream/shared/DomainSettings;->getOverride(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_4a

    invoke-virtual {p0, p1, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->cachedDomain(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    return-object v2

    .line 26
    :cond_4a
    iput-object p1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->L$0:Ljava/lang/Object;

    iput-object p2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->L$1:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$getDomain$1;->label:I

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0, v4, v0, v3, v5}, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshIfNeeded$default(Lapp/manitux/cloudstream/shared/RemoteConfig;ZLkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v2, :cond_5a

    .line 24
    return-object v2

    .line 27
    :cond_5a
    :goto_5a
    invoke-virtual {p0, p1, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->cachedDomain(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    return-object v2

    nop

    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_3a  #00000000
        :pswitch_2c  #00000001
    .end packed-switch
.end method

.method public final isSafeBaseUrl(Ljava/lang/String;)Z
    .registers 9
    .param p1, "value"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 95
    const/4 v0, 0x0

    :try_start_1
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Lapp/manitux/cloudstream/shared/RemoteConfig;

    .local v1, "$this$isSafeBaseUrl_u24lambda_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    const/4 v2, 0x0

    .line 96
    .local v2, "$i$a$-runCatching-RemoteConfig$isSafeBaseUrl$1":I
    new-instance v3, Ljava/net/URI;

    invoke-direct {v3, p1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .line 97
    .local v3, "uri":Ljava/net/URI;
    invoke-virtual {v3}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v4

    const-string v5, "https"

    const/4 v6, 0x1

    invoke-static {v4, v5, v6}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_60

    invoke-virtual {v3}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    if-eqz v4, :cond_2a

    invoke-static {v4}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_28

    goto :goto_2a

    :cond_28
    const/4 v4, 0x0

    goto :goto_2b

    :cond_2a
    :goto_2a
    const/4 v4, 0x1

    :goto_2b
    if-nez v4, :cond_60

    invoke-virtual {v3}, Ljava/net/URI;->getUserInfo()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_60

    .line 98
    invoke-virtual {v3}, Ljava/net/URI;->getQuery()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_60

    invoke-virtual {v3}, Ljava/net/URI;->getFragment()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_60

    invoke-virtual {v3}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    if-eqz v4, :cond_50

    invoke-static {v4}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_4e

    goto :goto_50

    :cond_4e
    const/4 v4, 0x0

    goto :goto_51

    :cond_50
    :goto_50
    const/4 v4, 0x1

    :goto_51
    if-nez v4, :cond_5f

    invoke-virtual {v3}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, "/"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_60

    :cond_5f
    goto :goto_61

    :cond_60
    const/4 v6, 0x0

    .end local v1  # "$this$isSafeBaseUrl_u24lambda_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    .end local v2  # "$i$a$-runCatching-RemoteConfig$isSafeBaseUrl$1":I
    .end local v3  # "uri":Ljava/net/URI;
    :goto_61
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    .line 95
    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_69
    .catchall {:try_start_1 .. :try_end_69} :catchall_6a

    goto :goto_75

    :catchall_6a
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 99
    :goto_75
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_80

    move-object v1, v0

    :cond_80
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0
.end method

.method public final parseDomains$FilmMakinesi_debug(Ljava/lang/String;)Ljava/util/Map;
    .registers 7
    .param p1, "text"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 85
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lapp/manitux/cloudstream/shared/RemoteConfig;

    .local v0, "$this$parseDomains_u24lambda_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    const/4 v1, 0x0

    .line 86
    .local v1, "$i$a$-runCatching-RemoteConfig$parseDomains$1":I
    invoke-static {}, Lcom/lagradost/cloudstream3/MainAPIKt;->getMapper()Lcom/fasterxml/jackson/databind/json/JsonMapper;

    move-result-object v2

    invoke-virtual {v2, p1}, Lcom/fasterxml/jackson/databind/json/JsonMapper;->readTree(Ljava/lang/String;)Lcom/fasterxml/jackson/databind/JsonNode;

    move-result-object v2

    .line 87
    .local v2, "root":Lcom/fasterxml/jackson/databind/JsonNode;
    invoke-virtual {v2}, Lcom/fasterxml/jackson/databind/JsonNode;->isObject()Z

    move-result v3

    if-nez v3, :cond_19

    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v3

    goto :goto_2e

    .line 88
    :cond_19
    invoke-virtual {v2}, Lcom/fasterxml/jackson/databind/JsonNode;->fields()Ljava/util/Iterator;

    move-result-object v3

    invoke-static {v3}, Lkotlin/sequences/SequencesKt;->asSequence(Ljava/util/Iterator;)Lkotlin/sequences/Sequence;

    move-result-object v3

    new-instance v4, Lapp/manitux/cloudstream/shared/RemoteConfig$$ExternalSyntheticLambda0;

    invoke-direct {v4, v0}, Lapp/manitux/cloudstream/shared/RemoteConfig$$ExternalSyntheticLambda0;-><init>(Lapp/manitux/cloudstream/shared/RemoteConfig;)V

    invoke-static {v3, v4}, Lkotlin/sequences/SequencesKt;->mapNotNull(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    move-result-object v3

    .line 92
    invoke-static {v3}, Lkotlin/collections/MapsKt;->toMap(Lkotlin/sequences/Sequence;)Ljava/util/Map;

    move-result-object v3

    .line 85
    .end local v0  # "$this$parseDomains_u24lambda_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    .end local v1  # "$i$a$-runCatching-RemoteConfig$parseDomains$1":I
    .end local v2  # "root":Lcom/fasterxml/jackson/databind/JsonNode;
    :goto_2e
    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_32
    .catchall {:try_start_0 .. :try_end_32} :catchall_33

    goto :goto_3e

    :catchall_33
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 93
    :goto_3e
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v1

    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_49

    move-object v0, v1

    :cond_49
    check-cast v0, Ljava/util/Map;

    return-object v0
.end method

.method public final rebaseSiteUrl(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 23
    .param p1, "url"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "current"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p4, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 46
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p3

    invoke-virtual {v1, v3}, Lapp/manitux/cloudstream/shared/RemoteConfig;->isSafeBaseUrl(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_d

    return-object v2

    .line 47
    :cond_d
    :try_start_d
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, v1

    check-cast v0, Lapp/manitux/cloudstream/shared/RemoteConfig;

    .line 102
    .local v0, "$this$rebaseSiteUrl_u24lambda_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    const/4 v4, 0x0

    .line 47
    .local v4, "$i$a$-runCatching-RemoteConfig$rebaseSiteUrl$uri$1":I
    new-instance v5, Ljava/net/URI;

    invoke-direct {v5, v2}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .end local v0  # "$this$rebaseSiteUrl_u24lambda_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    .end local v4  # "$i$a$-runCatching-RemoteConfig$rebaseSiteUrl$uri$1":I
    invoke-static {v5}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1c
    .catchall {:try_start_d .. :try_end_1c} :catchall_1d

    goto :goto_28

    :catchall_1d
    move-exception v0

    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_28
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2f

    const/4 v0, 0x0

    :cond_2f
    check-cast v0, Ljava/net/URI;

    if-nez v0, :cond_34

    return-object v2

    :cond_34
    move-object v4, v0

    .line 48
    .local v4, "uri":Ljava/net/URI;
    const-string v0, "http"

    const-string v6, "https"

    filled-new-array {v0, v6}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-virtual {v4}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_55

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v6, v7}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "toLowerCase(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_56

    :cond_55
    const/4 v6, 0x0

    :goto_56
    invoke-static {v0, v6}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_165

    invoke-virtual {v4}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_165

    invoke-virtual {v4}, Ljava/net/URI;->getUserInfo()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_6e

    move-object/from16 v7, p2

    move-object/from16 v6, p4

    goto/16 :goto_169

    .line 49
    :cond_6e
    sget-object v0, Lapp/manitux/cloudstream/shared/DomainSettings;->INSTANCE:Lapp/manitux/cloudstream/shared/DomainSettings;

    move-object/from16 v6, p4

    invoke-virtual {v0, v6}, Lapp/manitux/cloudstream/shared/DomainSettings;->knownDomains(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v0

    move-object/from16 v7, p2

    invoke-static {v0, v7}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v8

    .line 50
    .local v8, "known":Ljava/util/Set;
    move-object v9, v8

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 103
    .local v10, "$i$f$any":I
    instance-of v0, v9, Ljava/util/Collection;

    const/4 v11, 0x1

    if-eqz v0, :cond_94

    move-object v0, v9

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_94

    const/4 v12, 0x0

    goto :goto_f6

    .line 104
    :cond_94
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_98
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_f5

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element$iv":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/lang/String;

    .local v15, "base":Ljava/lang/String;
    const/16 v16, 0x0

    .line 51
    .local v16, "$i$a$-any-RemoteConfig$rebaseSiteUrl$belongsToSite$1":I
    sget-object v0, Lapp/manitux/cloudstream/shared/RemoteConfig;->INSTANCE:Lapp/manitux/cloudstream/shared/RemoteConfig;

    :try_start_a9
    sget-object v17, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 102
    .local v0, "$this$rebaseSiteUrl_u24lambda_u241_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    const/16 v17, 0x0

    .line 51
    .local v17, "$i$a$-runCatching-RemoteConfig$rebaseSiteUrl$belongsToSite$1$old$1":I
    new-instance v5, Ljava/net/URI;

    invoke-direct {v5, v15}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    .end local v0  # "$this$rebaseSiteUrl_u24lambda_u241_u240":Lapp/manitux/cloudstream/shared/RemoteConfig;
    .end local v17  # "$i$a$-runCatching-RemoteConfig$rebaseSiteUrl$belongsToSite$1$old$1":I
    invoke-static {v5}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b6
    .catchall {:try_start_a9 .. :try_end_b6} :catchall_b7

    goto :goto_c2

    :catchall_b7
    move-exception v0

    sget-object v5, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_c2
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_c9

    const/4 v0, 0x0

    :cond_c9
    check-cast v0, Ljava/net/URI;

    .line 52
    .local v0, "old":Ljava/net/URI;
    if-eqz v0, :cond_d2

    invoke-virtual {v0}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v5

    goto :goto_d3

    :cond_d2
    const/4 v5, 0x0

    :goto_d3
    invoke-virtual {v4}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v12

    invoke-static {v5, v12, v11}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_f0

    if-eqz v0, :cond_eb

    invoke-virtual {v0}, Ljava/net/URI;->getPort()I

    move-result v5

    invoke-virtual {v4}, Ljava/net/URI;->getPort()I

    move-result v12

    if-ne v5, v12, :cond_eb

    const/4 v5, 0x1

    goto :goto_ec

    :cond_eb
    const/4 v5, 0x0

    :goto_ec
    if-eqz v5, :cond_f0

    const/4 v0, 0x1

    goto :goto_f1

    :cond_f0
    const/4 v0, 0x0

    .line 104
    .end local v0  # "old":Ljava/net/URI;
    .end local v15  # "base":Ljava/lang/String;
    .end local v16  # "$i$a$-any-RemoteConfig$rebaseSiteUrl$belongsToSite$1":I
    :goto_f1
    if-eqz v0, :cond_98

    const/4 v12, 0x1

    goto :goto_f6

    .line 105
    .end local v14  # "element$iv":Ljava/lang/Object;
    :cond_f5
    const/4 v12, 0x0

    .line 50
    .end local v9  # "$this$any$iv":Ljava/lang/Iterable;
    .end local v10  # "$i$f$any":I
    :goto_f6
    move v0, v12

    .line 54
    .local v0, "belongsToSite":Z
    if-nez v0, :cond_fa

    return-object v2

    .line 55
    :cond_fa
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    new-array v9, v11, [C

    const/16 v10, 0x2f

    const/4 v11, 0x0

    aput-char v10, v9, v11

    invoke-static {v3, v9}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v4}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v9

    const-string v10, ""

    if-nez v9, :cond_117

    move-object v9, v10

    :cond_117
    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 56
    invoke-virtual {v4}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_138

    .line 102
    nop

    .local v9, "it":Ljava/lang/String;
    const/4 v11, 0x0

    .line 56
    .local v11, "$i$a$-let-RemoteConfig$rebaseSiteUrl$1":I
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v13, 0x3f

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .end local v9  # "it":Ljava/lang/String;
    .end local v11  # "$i$a$-let-RemoteConfig$rebaseSiteUrl$1":I
    if-nez v9, :cond_139

    :cond_138
    move-object v9, v10

    .line 55
    :cond_139
    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 56
    invoke-virtual {v4}, Ljava/net/URI;->getRawFragment()Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_15c

    .line 102
    nop

    .restart local v9  # "it":Ljava/lang/String;
    const/4 v11, 0x0

    .line 56
    .local v11, "$i$a$-let-RemoteConfig$rebaseSiteUrl$2":I
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v13, 0x23

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .end local v9  # "it":Ljava/lang/String;
    .end local v11  # "$i$a$-let-RemoteConfig$rebaseSiteUrl$2":I
    if-nez v9, :cond_15b

    goto :goto_15c

    :cond_15b
    move-object v10, v9

    .line 55
    :cond_15c
    :goto_15c
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    return-object v5

    .line 48
    .end local v0  # "belongsToSite":Z
    .end local v8  # "known":Ljava/util/Set;
    :cond_165
    move-object/from16 v7, p2

    move-object/from16 v6, p4

    :goto_169
    return-object v2
.end method

.method public final refreshAfterFailure(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 8
    .param p1, "key"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2, "fallback"  # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p3, "$completion"  # Lkotlin/coroutines/Continuation;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation

    instance-of v0, p3, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;

    if-eqz v0, :cond_14

    move-object v0, p3

    check-cast v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;

    iget v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->label:I

    const/high16 v2, -0x80000000

    and-int/2addr v1, v2

    if-eqz v1, :cond_14

    iget v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->label:I

    sub-int/2addr v1, v2

    iput v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->label:I

    goto :goto_19

    :cond_14
    new-instance v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;

    invoke-direct {v0, p0, p3}, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;-><init>(Lapp/manitux/cloudstream/shared/RemoteConfig;Lkotlin/coroutines/Continuation;)V

    .local v0, "$continuation":Lkotlin/coroutines/Continuation;
    :goto_19
    iget-object v1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->result:Ljava/lang/Object;

    .local v1, "$result":Ljava/lang/Object;
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v2

    .line 31
    iget v3, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->label:I

    packed-switch v3, :pswitch_data_50

    .end local v0  # "$continuation":Lkotlin/coroutines/Continuation;
    .end local v1  # "$result":Ljava/lang/Object;
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .restart local v0  # "$continuation":Lkotlin/coroutines/Continuation;
    .restart local v1  # "$result":Ljava/lang/Object;
    :pswitch_2c  #0x1
    iget-object v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->L$1:Ljava/lang/Object;

    move-object p2, v2

    check-cast p2, Ljava/lang/String;

    iget-object v2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->L$0:Ljava/lang/Object;

    move-object p1, v2

    check-cast p1, Ljava/lang/String;

    invoke-static {v1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_4b

    :pswitch_3a  #0x0
    invoke-static {v1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 32
    iput-object p1, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->L$0:Ljava/lang/Object;

    iput-object p2, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->L$1:Ljava/lang/Object;

    const/4 v3, 0x1

    iput v3, v0, Lapp/manitux/cloudstream/shared/RemoteConfig$refreshAfterFailure$1;->label:I

    invoke-direct {p0, v3, v0}, Lapp/manitux/cloudstream/shared/RemoteConfig;->refreshIfNeeded(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v2, :cond_4b

    .line 31
    return-object v2

    .line 33
    :cond_4b
    :goto_4b
    invoke-virtual {p0, p1, p2}, Lapp/manitux/cloudstream/shared/RemoteConfig;->cachedDomain(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    return-object v2

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_3a  #00000000
        :pswitch_2c  #00000001
    .end packed-switch
.end method
